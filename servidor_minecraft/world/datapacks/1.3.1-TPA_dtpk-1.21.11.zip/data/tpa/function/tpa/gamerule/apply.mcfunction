playsound minecraft:ui.button.click ambient @s
gamerule send_command_feedback false
tellraw @s ["",{"text":"[TPA] ","color":"yellow"},{"text":"Gamerule applied successfully!","color":"gold"}]