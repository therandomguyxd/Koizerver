data modify storage tpa:tpa temp.lang set value \
[ \
  {id: 0}, \
  {\
    lang: "zh_cn", \
    id: 1, \
    name: "zh_cn", \
    name_display: "简体中文（中国大陆）", \
    header: "[§bTPA§r] ", \
    back_act: "已将你传送至上一位置", \
    back_disabled: "§a返回上一位置§r已被服务器禁用", \
    back_not_exist: "没有找到上一位置", \
    back_spec: "旁观者模式玩家不允许§a返回上一位置§r", \
    book_check_missing: "检测到传送书丢失, 已重新给予", \
    book_disabled: "§a传送书§r已被服务器禁用", \
    book_incompatible: "§a传送书§r不兼容此游戏版本", \
    book_lore: "§r§b右键打开TPA菜单. 丢出刷新. 切换至副手停止使用.", \
    book_mainhand_busy: "请空手来获得传送书", \
    book_refresh: "你刷新了§a传送菜单书", \
    book_reget: "[§b重新获取§r]", \
    book_reget_hoverevent: "§b点击重新获取传送书", \
    book_spec: "旁观者模式玩家不允许使用§a传送书§r", \
    book_stacking: "检测到传送书堆叠, 已没收多余的书", \
    book_stop: "你已停止使用§a传送书§r, 可在TPA菜单里再次获取 ", \
    book_title: "§r§b传送菜单书 §a[扔出刷新] ", \
    dimension_menu_button: "[§b维度设置菜单§r]", \
    dimension_menu_button_hoverevent: "§b点击设置维度", \
    dimension_overworld: "主世界", \
    dimension_the_nether: "下界", \
    dimension_the_end: "末地", \
    dimension_unknown: "未知维度", \
    dimension_unknown_detected_leftpart: "检测到未知维度(", \
    dimension_unknown_detected_rightpart: "), 请在维度菜单设置: ", \
    extended_menu_incompatible: "§a展开菜单§r不兼容此游戏版本", \
    extended_menu_next_page: "§b查看下一页", \
    extended_menu_previous_page: "§b查看上一页", \
    extended_menu_title: "======================§bTPA§6 菜单§r========================", \
    here_button_tpa: "[§b请求传送§r]", \
    here_button_tpa_hoverevent: "§b点击快捷向他发送传送请求", \
    here_button_tpa_notavail_hoverevent: "§c玩家不允许被传送", \
    here_spec: "旁观者模式玩家不允许使用§a广播位置§r", \
    here_voxel_hoverevent: "§b点击添加VoxelMap路径点", \
    here_xaero_hoverevent: "§6点击添加Xearo's Minimap路径点", \
    home_act_left_part: "已将你传送至传送点#", \
    home_act_right_part: "", \
    home_create: "你尚未建立传送点", \
    home_create_button: "[§a新建§r]", \
    home_create_button_hoverevent: "§a点击设置一个传送点", \
    home_disabled: "§a传送点§r已被服务器禁用", \
    home_display: "§b传送点#", \
    home_display_rm_button: "[§c移除§r]", \
    home_display_rm_button_hoverevent: "§c点击删除这个传送点", \
    home_display_set_button: "[§a设置§r]", \
    home_display_set_button_hoverevent: "§a点击设置传送点", \
    home_display_tp_button: "[§b传送§r]", \
    home_display_tp_button_hoverevent: "§b点击传送到这个传送点", \
    home_menu_title: "你现在拥有如下的传送点槽位: ", \
    home_missing_hoverevent: "该传送点尚未设定", \
    home_new: "§a新建: ", \
    home_not_found_hoverevent: "§b你访问的传送点", \
    home_not_found_left_part: "你访问的传送点#", \
    home_not_found_right_part: "不存在", \
    home_number: "传送点#", \
    home_out_of_range_left_part: "你访问的传送点#", \
    home_out_of_range_right_part: "超出了服务器的限制", \
    home_remove_hoverevent: "§b移除的传送点", \
    home_remove_left_part: "你移除了传送点#", \
    home_remove_right_part: "", \
    home_set_left_part: "你把传送点#", \
    home_set_middle_part: "设置为", \
    home_set_position: "坐标", \
    home_set_right_part: "", \
    home_spec: "旁观者模式玩家不允许操作§a传送点§r", \
    hoverevent_suggest_tip: "§a你应将指令补全为: ", \
    idfix_act_hoverevent: "§b这名玩家使用了ID修复", \
    idfix_act_left_part: "", \
    idfix_act_right_part: "使用了§aID修复§r, 所有玩家的数据编号与上一位置已被重置", \
    idfix_cooldown: "§aID修复§r还在冷却中", \
    idfix_disabled: "§aID修复§r已被服务器禁用", \
    lang_button: "[§6点击这里选择语言§r]", \
    lang_button_hoverevent: "§b点击查看语言菜单", \
    lang_button_server: "[§6点击这里选择服务器语言§r]", \
    lang_disabled: "§a玩家选择语言§r已被服务器禁用", \
    lang_menu_select_button: "[§a加载推荐命令§r]", \
    lang_menu_select_button_hoverevent: "§b点击在聊天栏加载推荐命令: ", \
    lang_menu_title: "请在下方选择语言:", \
    lang_selected_left_part: "你已切换语言到", \
    lang_selected_right_part: "", \
    lang_server_follow_left_part: "由于数据包服务端默认语言尚未设置, 因此现在它被设置为", \
    lang_server_follow_right_part: "", \
    load_add_objectives: "正在添加46个记分项... (1/6)", \
    load_added_objectives: "已成功地添加记分项... (2/6)", \
    load_author: "此数据包由§6Xiao_tu233§r制作. ", \
    load_button_help: "[帮助]", \
    load_button_help_hoverevent: "点击查看帮助", \
    load_button_license: "[协议]", \
    load_button_license_hoverevent: "§b使用 TPA 数据包时请遵循我们在 GitHub 上开源协议. §b同时, 作者§l§n不建议§r§b将本数据包用于§l§n商业用途§r§b的服务器. §b为避免误解, 请您在使用前仔细阅读并理解完整协议内容. ", \
    load_button_options: "[设置]", \
    load_button_options_hoverevent: "点击更改数据包配置", \
    load_button_update: "[更新]", \
    load_button_update_hoverevent: "点击开始数据包的更新导引", \
    load_copyright_claim: "Copyright © 2024-2026 Xiao_tu233.    本数据包遵循 GPL-3.0 开源协议, 为开源项目, 但作者不建议将其用于商业化服务器.     点击下方“[协议]”查看协议原文. ", \
    load_date_check_left_part: "目前版本发布于", \
    load_date_check_format: 123, \
    load_date_check_format_comment: "§r§l§n# 1 for year, 2 for month, 3 for day, '123' here means the format is Year-Month-Day", \
    load_date_check_year_prefix: "", \
    load_date_check_year_suffix: "年", \
    load_date_check_year_local_prefix: "", \
    load_date_check_year_local_suffix: "", \
    load_date_check_month_prefix: "", \
    load_date_check_month_suffix: "月", \
    load_date_check_day_prefix: "", \
    load_date_check_day_suffix: "日", \
    load_date_check_right_part: ", 请注意更新", \
    load_did_reset_scores: "已成功重设在线玩家分数... (3/6)", \
    load_done: "§a数据包重载完成: ", \
    load_done_extra: " 完整版 ", \
    load_init_storage: "正在初始化相关命令存储... (3/6)", \
    load_init_vars: "正在初始化变量... (5/6)", \
    load_initted_storage: "已成功初始化相关命令存储... (4/6)", \
    load_initted_vars: "已成功初始化变量... (6/6)", \
    load_remove_tags: "正在移除标签... (4/6)", \
    load_removed_tags: "已成功移除标签... (5/6)", \
    load_reset_scores: " 正在重设在线玩家分数... (2/6)", \
    load_title: "§e重载中...", \
    load_version_hoverevent: "§b这是TPA数据包的版本, 而不是Minecraft版本.", \
    load_welcome: "欢迎使用TPA数据包! ", \
    mute_disable: "你开启了§a数据包音效§r", \
    mute_enable: "你§a静音§r了数据包", \
    option_advenced_warn: "下方设置为高级设置，请勿随意修改，除非你知道自己在做什么", \
    option_advenced_tip: "打开调试模式以调节更多设置(高级设置)", \
    option_anchor_search_retries: "寻找传送锚点的重试次数", \
    option_anchor_search_retries_hoverevent: "§b在下方更改§a寻找传送锚点的重试次数 §r(§6单位: 次 §r或 §6游戏刻/运行频率 §r), §b调节过大会延长等待, 过小可能导致锚点误判或污染", \
    option_back: "禁止玩家返回上一位置", \
    option_book: "禁止玩家使用传送书", \
    option_button_disable: "§c禁用§r]", \
    option_button_enable: "§r[§a启用§r", \
    option_button_help: "[§4帮助§r]", \
    option_button_help_hoverevent: "§b点击打开帮助菜单", \
    option_button_license: "[§4协议§r]", \
    option_button_license_hoverevent: "§b使用 TPA 数据包时请遵循我们在 GitHub 上开源协议. §b同时, 作者§l§n不建议§r§b将本数据包用于§l§n商业用途§r§b的服务器. §b为避免误解, 请您在使用前仔细阅读并理解完整协议内容. ", \
    option_button_notworking: "[§4无法运行§r]", \
    option_button_notworking_hoverevent: "§b当遇到tick函数无法运行(TPA菜单无法打开)时请点击", \
    option_button_set: "§r[§a设置§r]", \
    option_button_uninstall: "[§4卸载§r]", \
    option_button_uninstall_hoverevent: "§4点击此按钮来§l§n卸载§r§4TPA数据包! 请考虑你是否真的需要!", \
    option_button_update: "[§4更新§r]", \
    option_button_update_hoverevent: "§b点击开始更新数据包", \
    option_carpet_disabled: "本功能需要Carpet模组作为依赖, 而服务器尚未安装Carpet模组. ", \
    option_carpet_fake_player_fix: "Carpet模组假人修复", \
    option_carpet_fake_player_fix_incompatible: "Carpet模组假人修复不兼容该版本", \
    option_compact_ids: "是否在玩家离线后移除编号空位", \
    option_current_game_version: "当前检测到的游戏版本", \
    option_debug_mode: "调试模式", \
    option_debug_mode_hoverevent: "§b点击下方启用来启用调试模式 这会在聊天栏向你提供排除问题的相关讯息 但同时也可能导致刷屏 打开调试模式后再次打开设置菜单便可以调整高级设置", \
    option_dimension: "已兼容维度", \
    option_dimension_button_add: "[§a添加§r]", \
    option_dimension_button_add_hoverevent: "§b点击添加新维度", \
    option_dimension_button_edit_color: "[§a编辑颜色§r]", \
    option_dimension_button_edit_color_hoverevent: "§b点击编辑该维度的主题颜色(点击后请在指令末尾填写原版16色的英文或#XXXXXX的16进制格式, 输好后回车)", \
    option_dimension_button_edit_id: "[§a编辑维度ID§r]", \
    option_dimension_button_edit_id_hoverevent: "§b点击编辑该维度的维度ID(点击后请按下键盘上的左箭头, 在冒号后填写, 输好后回车)", \
    option_dimension_button_edit_namespaceid: "[§a编辑命名空间ID§r]", \
    option_dimension_button_edit_namespaceid_hoverevent: "§b点击编辑该维度的命名空间ID(namespace:id, source location 形如minecraft:xxx)(点击后请按两次键盘上的左箭头, 在引号中填写, 输好后回车)", \
    option_dimension_button_edit_name: "[§a编辑名字§r]", \
    option_dimension_button_edit_name_hoverevent: "§b点击编辑该维度的显示名称(点击后请按按两次键盘上的左箭头, 在引号中填写, 输好后回车, 该项对于原版维度会跟随语言设置而不是当前设置)", \
    option_dimension_button_remove: "[§c移除§r]", \
    option_dimension_button_remove_hoverevent: "§b点击移除该维度", \
    option_dimension_button_remove_notavail_hoverevent: "§c原版维度无法移除", \
    option_dimension_hoverevent: "§b在下方设置按钮打开§a维度兼容§6菜单 §b同时右侧的数字会是目前已兼容的维度数量", \
    option_dimension_menu_title: "服务器兼容了如下的维度: ", \
    option_dimension_number_hoverevent_leftpart: "§b服务器目前兼容了 ", \
    option_dimension_number_hoverevent_rightpart: " 个维度", \
    option_disabled: "§c禁用§r", \
    option_enabled: "§a启用§r", \
    option_frequency: "数据包运行频率", \
    option_frequency_hoverevent: "§b在下方更改§a数据包运行频率 §r(§6单位: 1 游戏刻 = 1/20 秒§r), §b点击禁用来暂时停止数据包运作", \
    option_game_version: "数据包文件兼容的游戏版本", \
    option_home: "拥有传送点的个数", \
    option_home_hoverevent: "§b在下方更改§a拥有传送点的个数 §r(§6单位: 个§r), §b填0来设置禁止传送点, §b填-1来设置不限制传送点的数量(不推荐)", \
    option_idfix_cooldown: "§bID修复冷却时间", \
    option_idfix_cooldown_hoverevent: "§b在下方更改§aID修复冷却时间 §r(§6单位: 1 游戏刻 = 1/20 秒§r), §b填0来设置无冷却, 填-1来设置禁止ID修复", \
    option_lang: "服务器语言", \
    option_lang_hoverevent: "§b在下方进入语言选择菜单", \
    option_player_lang: "是否允许玩家语言选择", \
    option_max_anchor_summons_attempts: "传送锚点最大召唤尝试次数", \
    option_max_anchor_summons_attempts_hoverevent: "§b在下方更改§a传送锚点最大召唤尝试次数 §r(§6单位: 次§r) §b调节过大会增加卡顿和无效等待, 过小可能导致传送频繁失败", \
    option_search_id: "是否禁用搜索玩家编号", \
    option_sim_dist: "模拟距离", \
    option_sim_dist_button_cal: "[§a计算§r]", \
    option_sim_dist_hoverevent: "§b在下方更改§a模拟距离 §r(§6单位: 区块§r)  请在点击前保证主世界原点模拟距离内没有玩家", \
    option_stricter_book_check: "更严格的传送书检测", \
    option_stricter_book_check_incompatible: "更严格的传送书检测不兼容该版本", \
    option_stricter_book_check_disabled: "本功能需要Bookshelf数据包作为依赖, 而服务器尚未安装Bookshelf数据包. ", \
    option_time_out: "传送请求超时时间", \
    option_time_out_hoverevent: "§b在下方更改§a传送请求超时时间 §r(§6单位: 1 游戏刻 = 1/20 秒§r), §b填0来设置禁止传送 §b填-1来设置永不超时", \
    option_title_line1: "======================§bTPA§6 设置菜单§r=====================", \
    option_title_line2: "请在下方调整设置: (需重新呼出菜单以查看更改)", \
    option_tp_pos: "传送坐标允许半径", \
    option_tp_pos_cooldown: "传送坐标冷却时间", \
    option_tp_pos_cooldown_hoverevent: "§b在下方更改§a冷却时间 §r(§6单位: 1 游戏刻 = 1/20 秒§r), §b填0来设置无冷却 §b填-1来设置禁止传送", \
    option_tp_pos_hoverevent: "§b在下方更改§a传送坐标允许半径 §r(§6单位: 米§r), §b填0来设置禁止传送 §b填-1来设置不限制半径(不推荐)", \
    option_tp_spec: "允许传送旁观者", \
    option_server_calling: "Qing3 shi3yong4 Ke4hu4duan1, er2 bu2shi4 Kong4zhi4tai2 lai2 tiao2zheng3 she4zhi4!", \
    option_server_calling_comment: "§l§n§4这里是一个注释 因为上面的option_server_calling需要被控制台所显示 如果直接写汉字会被显示为乱码 这里使用拼音来进行表示", \
    option_uses_binary_teleport: "是否使用二分法传送", \
    option_uses_binary_teleport_hoverevent: "§b在下方选择§a使用二分法传送(启用) §6抑或是 §c使用锚点传送(禁用)", \
    option_uses_string_dimension: "是否识别字符串维度", \
    option_uses_string_dimension_hoverevent: "§b在下方选择§a用字符串储存维度1.16+(启用) §6抑或是 §c用整型储存维度1.16-(禁用)", \
    option_version: "数据包版本", \
    option_warp: "公共传送点", \
    option_warp_hoverevent: "§b在下方设置按钮打开§a公共传送点§6菜单 §b同时右侧的数字会是目前已经设置的公共传送点数量", \
    option_warp_number_hoverevent_leftpart: "§b服务器目前设置了 ", \
    option_warp_number_hoverevent_rightpart: "§b 个公共传送点", \
    option_uses_tick_scheduling: "是否使用/schedule指令调用Tick函数", \
    output_default: "你将输出位置切换为§a聊天栏和动作栏§r", \
    output_hide_actionbar: "你将输出位置切换为§a仅聊天栏§r", \
    output_hide_chatbar: "你将输出位置切换为§a仅动作栏§r", \
    recver_accept_auto_hoverevent: "§b向你发送传送请求的玩家", \
    recver_accept_auto_left_part: "自动接受了", \
    recver_accept_auto_right_part: "的传送请求", \
    recver_accept_toggle_off: "你关闭了§a自动接受§r", \
    recver_accept_toggle_on: "你开启了§a自动接受§r", \
    recver_accept_tpa_hoverevent: "§b你所接受传送请求的玩家", \
    recver_accept_tpa_left_part: "你接受了", \
    recver_accept_tpa_right_part: "的传送请求", \
    recver_accept_tpahere_hoverevent: "§b你所接受§l传送此处§r请求的玩家", \
    recver_accept_tpahere_left_part: "你接受了", \
    recver_accept_tpahere_right_part: "的§l传送此处§r请求", \
    recver_cancel_hoverevent: "§b取消对你请求的玩家", \
    recver_cancel_left_part: "", \
    recver_cancel_right_part: "取消了对你的请求", \
    recver_deny_tpa_hoverevent: "§b你所拒绝传送请求的玩家", \
    recver_deny_tpa_left_part: "你拒绝了", \
    recver_deny_tpa_right_part: "的传送请求", \
    recver_deny_tpahere_hoverevent: "§b你所拒绝§l传送此处§r请求的玩家", \
    recver_deny_tpahere_left_part: "你拒绝了", \
    recver_deny_tpahere_right_part: "的§l传送此处§r请求", \
    recver_recv_button_accept: "[§a接受§r]", \
    recver_recv_button_accept_hoverevent: "§b点击接受他的请求", \
    recver_recv_button_deny: "[§c拒绝§r]", \
    recver_recv_button_deny_hoverevent: "§b点击拒绝他的请求", \
    recver_recv_tpa_actionbar_left_part: "", \
    recver_recv_tpa_actionbar_right_part: "向你发送了一个传送请求, 使用/trigger tpaccept来接受请求", \
    recver_recv_tpa_chatbar_left_part: "", \
    recver_recv_tpa_chatbar_right_part: "向你发送了一个传送请求", \
    recver_recv_tpa_hoverevent: "§b向你发送传送请求的玩家", \
    recver_recv_tpahere_actionbar_left_part: "", \
    recver_recv_tpahere_actionbar_right_part: "向你发送了一个§l传送此处§r请求, 使用/trigger tpaccept来接受请求", \
    recver_recv_tpahere_chatbar_left_part: "", \
    recver_recv_tpahere_chatbar_right_part: "向你发送了一个§l传送此处§r请求", \
    recver_recv_tpahere_hoverevent: "§b向你发送§l传送此处§r请求的玩家", \
    recver_req_not_exist: "没有 需要处理的请求", \
    recver_timeout_hoverevent: "§b向你发送超时请求的玩家", \
    recver_timeout_left_part: "", \
    recver_timeout_right_part: "的传送请求已超时", \
    reqer_accept_auto_hoverevent: "§b自动同意了你的传送请求的玩家", \
    reqer_accept_auto_left_part: "对方开启了自动接受, 将你传送至", \
    reqer_accept_auto_right_part: "...", \
    reqer_accept_tpa_hoverevent: "§b接受了你的传送请求的玩家", \
    reqer_accept_tpa_left_part: "正在传送你至", \
    reqer_accept_tpa_right_part: "...", \
    reqer_accept_tpahere_hoverevent: "§b接受了你的§l传送此处§r请求的玩家", \
    reqer_accept_tpahere_left_part: "正在传送", \
    reqer_accept_tpahere_right_part: "至你...", \
    reqer_button_tpa: "[§b传送§r]", \
    reqer_button_tpa_hoverevent: "§b点击传送向他发送传送请求", \
    reqer_button_tpahere: "[§b传送此处§r]", \
    reqer_button_tpahere_hoverevent: "§b点击请求他传送到你的当前位置", \
    reqer_cancel_hoverevent: "§b你取消了请求的玩家", \
    reqer_cancel_left_part: "你取消了向", \
    reqer_cancel_right_part: "的请求", \
    reqer_cancel_spec: "旁观者模式玩家不允许§a取消请求§r", \
    reqer_change_actionbar_left_part: "你之前发送过了一个向", \
    reqer_change_actionbar_middle_part: "的请求, 已取消前一个请求. 现在向", \
    reqer_change_actionbar_right_part: "发送了请求, 等待他接受. ", \
    reqer_change_chatbar_left_part: "你之前发送过了一个 向", \
    reqer_change_chatbar_middle_part: "的请求, 已取消前一个请求. 现在向", \
    reqer_change_chatbar_right_part: "发送了请求, 等待他接受", \
    reqer_change_hoverevent: "§b你之前发送请求的玩家", \
    reqer_deny_tpa_hoverevent: "§b拒绝了你的传送请求的玩家", \
    reqer_deny_tpa_left_part: "", \
    reqer_deny_tpa_right_part: "拒绝了你的传送请求", \
    reqer_deny_tpahere_hoverevent: "§b拒绝了你的§l传送此处§r请求的玩家", \
    reqer_deny_tpahere_left_part: "", \
    reqer_deny_tpahere_right_part: "拒绝了你的传送请求", \
    reqer_disabled: "服务器不允许§a传送§r", \
    reqer_first_join: "[§6点我打开TPA菜单§r]", \
    reqer_no_req_found: "你还未向玩家发送任何请求", \
    reqer_recver_invalid: "你请求的玩家已离线或不允许被传送", \
    reqer_req_button_cancel: "[§4取消§r]", \
    reqer_req_button_cancel_hoverevent: "§b点击取消请求", \
    reqer_req_hoverevent: "§b你所发送请求的玩家", \
    reqer_req_not_exist: "请求的玩家不存在或不在线", \
    reqer_req_tpa_actionbar_left_part: "你向", \
    reqer_req_tpa_actionbar_right_part: "发送了一个传送请求. 等待他接受", \
    reqer_req_tpa_chatbar_left_part: "你向", \
    reqer_req_tpa_chatbar_right_part: "发送了一个传送请求. 等待他接受", \
    reqer_req_tpa_hoverevent: "§b你所发送传送请求的玩家", \
    reqer_req_tpahere_actionbar_left_part: "你向", \
    reqer_req_tpahere_actionbar_right_part: "发送了一个传送他到你的所在位置的请求. 等待他接受", \
    reqer_req_tpahere_chatbar_left_part: "你向", \
    reqer_req_tpahere_chatbar_right_part: "发送了一个传送他到你的所在位置请求. 等待他接受", \
    reqer_req_tpahere_hoverevent: "§b你所发送§l传送此处§r请求的玩家", \
    reqer_self: "你不能tp你自己", \
    reqer_spam: "你已经向他发送过请求了", \
    reqer_spec: "旁观者模式玩家不允许§a传送§r", \
    reqer_timeout_hoverevent: "§b未接受你的请求的玩家", \
    reqer_timeout_left_part: "你向", \
    reqer_timeout_right_part: "的传送请求已超时", \
    search_id_abort: "你停止了§a搜索玩家编号§r", \
    search_id_dialog_done_tooltip: "§b点击提交名字", \
    search_id_dialog_cancel: "取消", \
    search_id_dialog_cancel_tooltip: "§b点击取消输入", \
    search_id_disabled: "§a搜索玩家编号§r被服务器禁用", \
    search_id_incompatible: "§a搜索玩家编号§r不兼容该游戏版本", \
    search_id_keyboard_title: "请点击下方键盘按键来在上方输入玩家名: ", \
    search_id_name_input: "已输入: ", \
    search_id_recall: "[§b重新呼出§r]", \
    search_id_recall_hoverevent: "§b重新呼出搜索玩家编号软键盘", \
    search_id_throw_on_invalid_char: "你输入的名字包含不合法的字符", \
    search_id_unavail_player: "对方不在线或不允许被传送", \
    simple_menu_button: "[§b详细菜单§r]", \
    simple_menu_button_hoverevent: "§b点击切换至详细菜单", \
    simple_menu_disable: "你将TPA菜单切换至§a详细菜单", \
    simple_menu_incompatible: "§a简略菜单§r不兼容此游戏版本", \
    simple_menu_enable: "你将TPA菜单切换至§a简略菜单 §r你现在可以直接使用/trigger tpa来打开简略菜单", \
    simple_menu_title: "点击下方玩家名发送传送请求", \
    teleport_anchor_actionbar: "锚点传送进度: ", \
    teleport_binary_actionbar: "二分法传送进度: ", \
    teleport_cal_sim_dist_actionbar: "模拟距离", \
    teleport_cal_sim_dist_end_leftpart: "模拟距离计算成功, 目前服务器所设置数据包模拟距离为: ", \
    teleport_cal_sim_dist_end_rightpart: "", \
    teleport_cal_sim_dist_start: "计算模拟距离已开始", \
    teleport_incompatible: "§a锚点传送§r不兼容此游戏版本", \
    teleport_sim_dist_disabled: "服务器尚未设置模拟距离", \
    teleport_sim_dist_warn: "检测到服务器未设置模拟距离，当前尝试对非玩家目标进行传送。若出现失败，请联系管理员重新计算距离，或手动设置参数，或使用二分法传送", \
    teleport_sim_dist_warn_button_calc: "[§a计算§r]", \
    teleport_sim_dist_warn_button_calc_hoverevent: "§b点击开始自动计算模拟距离   §c注意: 执行可能会导致执行者被传送到其他位置   请确保你的位置不需要保持加载再点击", \
    teleport_sim_dist_warn_button_binary: "[§a二分法§r]", \
    teleport_sim_dist_warn_button_binary_hoverevent: "§b点击将传送方式设置为二分法传送", \
    tick_not_working_button_set_schedule: "§b[设置]", \
    tick_not_working_button_set_schedule_hoverevent: "§b点击设置/schedule指令调用Tick函数", \
    tick_not_working_server_calling: "Qing3 shi3yong4 Ke4hu4duan1, er2 bu2shi4 Kong4zhi4tai2 lai2 huo4qu3 Ming4ling4fang1kuai4!", \
    tick_not_working_server_calling_comment: "§l§n§c这里是一个注释 因为上面的tick_not_working_server_calling需要被控制台所显示 如果直接写汉字会被显示为乱码 这里使用拼音来进行表示", \
    tick_not_working_tips_line1: "你现在正在调用Tick不工作函数 因此你应该遇到了Tick函数不工作的情况 你现在可以实现以下两种方式的其中一种:", \
    tick_not_working_tips_line2: "        1. 设置使用/schedule指令调用Tick函数", \
    tick_not_working_tips_line3: "   或者 2. 把你手中的命令方块放到隐蔽的位置 以避免被破基岩机破坏", \
    tp_pos_abort: "你已停止输入传送坐标", \
    tp_pos_act_left_part: "已将你传送至坐标", \
    tp_pos_act_right_part: "", \
    tp_pos_button_abort: "[停止]", \
    tp_pos_button_teleport: "[传送]", \
    tp_pos_cooldown: "§a传送坐标§r还在冷却中", \
    tp_pos_disabled: "服务器设置未启用§a传送坐标§r", \
    tp_pos_dialog_cancel_tooltip: "§b点击取消输入", \
    tp_pos_dialog_done_tooltip: "§b点击传送提交的坐标", \
    tp_pos_dialog_set: "当前: ", \
    tp_pos_dialog_set_x: "设置X坐标", \
    tp_pos_dialog_set_x_tooltip: "§b点击设置X坐标", \
    tp_pos_dialog_set_y: "设置Y坐标", \
    tp_pos_dialog_set_y_tooltip: "§b点击设置Y坐标", \
    tp_pos_dialog_set_z: "设置Z坐标", \
    tp_pos_dialog_set_z_tooltip: "§b点击设置Z坐标", \
    tp_pos_out_of_range: "传送距离超过了服务器设定的半径", \
    tp_pos_recall: "[§b重新呼出§r]", \
    tp_pos_recall_hoverevent: "§b点击重新呼出传送坐标菜单", \
    tp_pos_spec: "旁观者模式玩家不允许§a传送坐标§r", \
    tp_pos_throw_on_invalid_char: "你输入的坐标包含不合法的字符", \
    tp_pos_title: "在下方调整坐标: ", \
    tpa_menu_auto_accept: "自动接受: ", \
    tpa_menu_back_button: "[§b返回上一位置§r]", \
    tpa_menu_back_button_hoverevent: "§b回到传送前位置", \
    tpa_menu_book_button: "[§b获取传送书§r]", \
    tpa_menu_book_button_hoverevent: "§b点击来获取传送书", \
    tpa_menu_dialog: "[§b对话框菜单§r]", \
    tpa_menu_dialog_title: "§bTPA菜单", \
    tpa_menu_dialog_hoverevent: "§b点击打开对话框菜单", \
    tpa_menu_switch_hoverevent: "§b点击切换", \
    tpa_menu_disable: "§c关闭§r]", \
    tpa_menu_disabled: "§c禁用", \
    tpa_menu_disabled_hoverevent: "§b点击切换到§a启用", \
    tpa_menu_enable: "[§a开启§r", \
    tpa_menu_enabled: "§a启用", \
    tpa_menu_enabled_hoverevent: "§b点击切换到§c禁用", \
    tpa_menu_extend: "§b更多§r", \
    tpa_menu_extend_hoverevent: "§b点击展开菜单", \
    tpa_menu_has_id_of: "的§a数据包编号§r是", \
    tpa_menu_has_id_of_hoverevent: "§b数据包内部为每名玩家分配的编号 用于对应玩家", \
    tpa_menu_here_button: "[§b广播位置§r]", \
    tpa_menu_here_button_hoverevent: "§b点击广播你的位置", \
    tpa_menu_home_button: "[§b家菜单§r]", \
    tpa_menu_home_button_hoverevent: "§b点击打开私人传送点(家)菜单", \
    tpa_menu_warp_button: "[§b地标菜单§r]", \
    tpa_menu_warp_button_hoverevent: "§b点击打开公共传送点(地标)菜单", \
    tpa_menu_hoverevent_left_part: "§b点击向", \
    tpa_menu_hoverevent_right_part: "§b发送传送请求", \
    tpa_menu_idfix_button: "[§bID修复§r]", \
    tpa_menu_idfix_button_hoverevent: "§b如果你遇到两个相同玩家拥有同一id的问题, 你可以尝试这个修复. 此修复会重置所有玩家的id.", \
    tpa_menu_lang_button: "[§b切换语言§r]", \
    tpa_menu_lang_button_hoverevent: "§b点击切换语言", \
    tpa_menu_mute: "静音数据包: ", \
    tpa_menu_output: "输出显示位置: ", \
    tpa_menu_output_actionbar: "§b隐藏聊天栏§r", \
    tpa_menu_output_chatbar: "§b隐藏动作栏§r]", \
    tpa_menu_output_default: "[§b默认§r", \
    tpa_menu_output_actionbar_hidden: "§b仅聊天栏§r", \
    tpa_menu_output_chatbar_hidden: "§b仅动作栏§r", \
    tpa_menu_output_no_hidden: "§b动作栏和聊天栏§r", \
    tpa_menu_pos_button: "[§b传送坐标§r]", \
    tpa_menu_pos_button_hoverevent: "§b点击呼出传送坐标菜单", \
    tpa_menu_refresh: "[§6刷新TPA菜单§r]", \
    tpa_menu_refresh_hoverevent: "§b点击此处刷新或重新呼出TPA菜单", \
    tpa_menu_search_id_button: "[§b搜索玩家§r]", \
    tpa_menu_search_id_button_hoverevent: "§b点击呼出聊天栏键盘来搜索用户名", \
    tpa_menu_simplemenu_button: "[§b简略菜单§r]", \
    tpa_menu_simplemenu_button_hoverevent: "§b切换到简略菜单", \
    tpa_menu_title: "下方是玩家数据包编号和游戏用户名, 点击编号来请求传送§l其他玩家§r: {", \
    tpa_menu_tpaheremenu_button: "[§b传送此处菜单§r]", \
    tpa_menu_tpaheremenu_button_hoverevent: "§b点击来跳转到传送此处菜单", \
    tpa_menu_tpamenu_button: "[§b传送菜单§r]", \
    tpa_menu_tpamenu_button_hoverevent: "§b点击来跳转到传送菜单", \
    tpa_menu_you: "你", \
    tpahere_menu_title: "下方是玩家数据包编号和游戏用户名, 点击编号来请求其他玩家传送§l你§r: {", \
    uninstall_start: "正在卸载... (0/2)", \
    uninstall_rmv_objs: "移除所有记分项... (0/2)", \
    uninstall_rmv_done_1: "成功移除. (1/2)", \
    uninstall_rmv_tags: "正在移除所有标签... (1/2)", \
    uninstall_rmv_done_2: "成功移除. (2/2)", \
    uninstall_done_leftpart: "§a成功卸载. 使用", \
    uninstall_done_hoverevent: "点击运行命令", \
    uninstall_done_rightpart: "来再次启用", \
    update_reload: "§b[重载]", \
    update_reload_hoverevent: "点击重载", \
    update_step1_leftpart: "您正在进行TPA数据包的更新程序 目前已安装的数据包版本是 ", \
    update_step1_rightpart: " 请在此处确认开始更新", \
    update_step1_button: "§b§n§l[我知道我在做什么]", \
    update_step1_hoverevent: "请谨慎点击", \
    update_step2: "请从github,QQ群或Modrinth中下载最新版本的数据包备用", \
    update_step3: "请点击右手边的按钮将数据包暂时禁用 以便下一步的安装", \
    update_step3_button: "§b[禁用数据包]", \
    update_step3_hoverevent: "如果遇到无法禁用 请检查数据包的文件名是否正确", \
    update_step4: "我们即将完成, 请将数据包文件拖入datapacks文件夹并解压 然后删掉原来的数据包", \
    update_step5_leftright: "后, 我们已经完成了TPA数据包的安装 如果数据包使用没有问题 请开始调整数据包设置 如果数据包没有正确加载 请尝试", \
    update_step5_button: "§b[加载]", \
    update_step5_hoverevent: "点击加载数据包", \
    update_step5_rightpart: " 如果出现未知的记分项 请从第3步开始检查 这可能是由数据包安装版本不正确或未知不正确所导致的 其他问题请咨询Xiao_tu233", \
    update_nextstep: "§b[下一步]", \
    warp_button_add: "[§a新建传送点§r]", \
    warp_button_add_hoverevent: "§b点击在当前位置新建一个公共传送点", \
    warp_button_apply: "[§a应用§r]", \
    warp_button_apply_hoverevent: "§b点击应用所缓存的更改", \
    warp_button_cancel: "[§c取消§r]", \
    warp_button_cancel_hoverevent: "§b点击放弃所缓存的更改", \
    warp_button_enable: "[§a启用§r]", \
    warp_button_enable_hoverevent: "§b点击启用该公共传送点", \
    warp_button_disable: "[§c禁用§r]", \
    warp_button_disable_hoverevent: "§b点击禁用该公共传送点(除名字之外的相关信息将被隐藏 启用以查看)", \
    warp_button_moveup: "[§d上移§r]", \
    warp_button_moveup_hoverevent: "§b点击互换该公共传送点与上方公共传送点的位置", \
    warp_button_moveup_notavail_hoverevent: "§c无法上移, 该传送点已经位于最上方", \
    warp_button_movedown: "[§d下移§r]", \
    warp_button_movedown_hoverevent: "§b点击互换该公共传送点与下方公共传送点的位置", \
    warp_button_tp: "[§b传送§r]", \
    warp_button_tp_hoverevent: "§b点击传送到该公共传送点", \
    warp_button_rm: "[§c移除§r]", \
    warp_button_rm_hoverevent: "§b点击移除该公共传送点", \
    warp_button_select: "[§a选择§r]", \
    warp_button_select_hoverevent: "§b点击选择该公共传送点槽位, 以作为应用时写入更改的槽位", \
    warp_button_unselect: "[§c取消选择§r]", \
    warp_button_unselect_hoverevent: "§b点击取消选择该公共传送点槽位", \
    warp_button_setdesc: "[§a设描述§r]", \
    warp_button_setdesc_hoverevent: "§b点击设置该公共传送点的描述(点击后请按下键盘上的左箭头, 在引号中填写, 输好后回车)", \
    warp_button_setname: "[§a取名§r]", \
    warp_button_setname_hoverevent: "§b点击设置该公共传送点的名字(点击后请按下键盘上的左箭头, 在引号中填写, 输好后回车)", \
    warp_button_setpos: "[§a取址§r]", \
    warp_button_setpos_hoverevent: "§b点击把该公共传送点设置到当前位置", \
    warp_desc_disabled: "§c该公共传送点已被禁用", \
    warp_disabled: "§a公共传送点§r已被服务器禁用", \
    warp_menu_title: "服务器设置了如下的公共传送点: ", \
    warp_menu_edit_tip: "目前处于编辑模式 请在下方通过索引选择操作槽位后在下方按钮更改具体数据最后点击应用来应用更改", \
    warp_number: "公共传送点#", \
    warp_out_of_range: "该公共传送点尚未设置", \
    warp_select_left_part: "你选中了", \
    warp_select_right_part: "作为正在编辑的槽位", \
    warp_set_left_part: "你把", \
    warp_set_middle_part: "设置为", \
    warp_set_position: "坐标", \
    warp_set_right_part: "", \
    warp_set_default_name: "未命名传送点", \
    warp_slot_disabled_leftpart: "你所访问的公共传送点", \
    warp_slot_disabled_rightpart: "已被禁用", \
    warp_spec: "旁观者模式玩家不允许传送§a公共传送点§r", \
    warp_teleport_left_part: "已将你传送至", \
    warp_teleport_right_part: "" \
}, \
  {\
    lang: "en_us", \
    id: 2, \
    name: "en_us", \
    name_display: "English (United States)", \
    back_act: "Teleported you to the previous position", \
    back_disabled: "Server doesn't allow going §aBack§r", \
    back_not_exist: "No previous position found", \
    back_spec: "Spectator mode players can't go §aBack§r", \
    book_disabled: "Server doesn't allow §aTPA Book§r", \
    book_lore: "§r§bRight click to open TPA menu. Drop to refresh. Switch offhand to stop using.", \
    book_title: "§r§bTPA menu book §a[Press Q to Refresh] ", \
    book_mainhand_busy: "Please hold your main hand to get the book.", \
    book_spec: "Spectator mode players can't use §aTPA Book§r", \
    book_stop: "You have stopped using §aTPA Book§r, you can get it again in TPA menu", \
    command_syntax_error: "Command syntax error", \
    extended_menu_title: "======================§bTPA§6 Menu§r=======================", \
    extended_menu_previous_page: "§bPrevious page", \
    extended_menu_next_page: "§bNext page", \
    here_button_tpa: "[§bRequest Teleport§r]", \
    here_button_tpa_hoverevent: "§bClick to send a teleport request to the player", \
    here_voxel_hoverevent: "§bClick to add VoxelMap Waypoint", \
    here_xaero_hoverevent: "§6Click to add Xearo's Minimap Waypoint", \
    here_spec: "Spectator mode players can't use §aBroadcast Position§r", \
    home_act_left_part: "You have teleported to Home#", \
    home_act_right_part: "", \
    home_create: "You haven't set any home yet.", \
    home_create_button: "[§aCreate§r]", \
    home_create_button_hoverevent: "§aClick to set a home", \
    home_disabled: "Server haven't enabled §aHome§r", \
    home_display: "§bHome#", \
    home_display_tp_button: "[§bTeleport§r]", \
    home_display_tp_button_hoverevent: "§bClick to teleport to this home", \
    home_display_rm_button: "[§cRemove§r]", \
    home_display_rm_button_hoverevent: "§cClick to remove this home", \
    home_display_set_button: "[§aSet§r]", \
    home_display_set_button_hoverevent: "§aClick to set home's position", \
    home_menu_title: "You own now following homes slot: ", \
    home_missing_hoverevent: "This home hasn't been set", \
    home_new: "§aCreate: ", \
    home_number: "Home#", \
    home_not_found_left_part: "The Home#", \
    home_not_found_hoverevent: "§bThe home you are looking for", \
    home_not_found_right_part: "doesn't exist", \
    home_out_of_range_left_part: "The Home#", \
    home_out_of_range_right_part: "is out of the server limit.", \
    home_remove_left_part: "You removed Home#", \
    home_remove_hoverevent: "§bHome which has been removed", \
    home_remove_right_part: "", \
    home_set_left_part: "You have set Home#", \
    home_set_middle_part: "at", \
    home_set_overworld: "§aOverworld", \
    home_set_the_nether: "§cNether", \
    home_set_the_end: "§eThe End", \
    home_set_position: "Positon", \
    home_set_right_part: "", \
    home_spec: "Spectators are not allowed to modify §aHomes§r", \
    idfix_act_left_part: "", \
    idfix_act_hoverevent: "§bThis player used ID fix", \
    idfix_act_right_part: "used ID fix, all player's datapack ID has been reset to the previous position", \
    idfix_cooldown: "§aID fix§r is on cooldown", \
    idfix_disabled: "Server doesn't allow §aID fix§r", \
    lang_button: "[§6Click here to select language§r]", \
    lang_button_server: "[§6Click here to select server language§r]", \
    lang_button_hoverevent: "§bClick to open language menu", \
    lang_menu_title: "Please select language below:", \
    lang_menu_select_button: "[§aLoad recommended commands§r]", \
    lang_menu_select_button_hoverevent: "§bClick to load recommended commands in chat bar:                                       ", \
    lang_disabled: "Language feature is disabled", \
    lang_selected_left_part: "You have switched language to ", \
    lang_selected_right_part: "", \
    lang_server_follow_left_part: "Since Datapack default language haven't been set, so it's set to ", \
    lang_server_follow_right_part: " now", \
    load_title: "§eReloading...", \
    load_add_objectives: "Adding 42 objectives... (1/6)", \
    load_added_objectives: "Objectives have been added... (2/6)", \
    load_reset_scores: "Resetting online player scores... (2/6)", \
    load_did_reset_scores: "Online player scores have been reset... (3/6)", \
    load_init_storage: "Initializing data storage... (3/6)", \
    load_initted_storage: "Data storage has been initialized... (4/6)", \
    load_remove_tags: "Removing tags... (4/6)", \
    load_removed_tags: "Tags are removed... (5/6)", \
    load_init_vars: "Initializing variables... (5/6)", \
    load_initted_vars: "Variables have been initialized... (6/6)", \
    load_done: "§aData pack has been reloaded: ", \
    load_version_hoverevent: "§bIt's the version of TPA Datapack, Instead of Minecraft Version.", \
    load_welcome: "Welcome use TPA Datapack! ", \
    load_copyright_claim: "Copyright © 2024-2025 Xiao_tu233 All rights reserved. No Commercial use. Click \"[LICENSE]\" button below for details", \
    load_author: "This datapack is made by §6Xiao_tu233§r. ", \
    load_button_options: "[SETTINGS]", \
    load_button_options_hoverevent: "Click to modify options", \
    load_button_help: "[HELP]", \
    load_button_help_hoverevent: "Click to see help", \
    load_button_update: "[UPDATE]", \
    load_button_update_hoverevent: "Click to start updating datapack", \
    load_button_license: "[LICENSE]", \
    load_button_license_hoverevent: "§bTo use TPA datapack, you must follow the open source license we put on Github website and the restrictions on §l§ncommercial§r§b use. Otherwise, a §6§lcopyright infringement§r§b risk will exist. So please read the whole text carefully.", \
    mute_disable: "You have enabled §aDatapack sounds§r", \
    mute_enable: "You have §amuted§r datapack", \
    option_carpet_disabled: "This feature needs Carpet Mod as a dependency, However Carpet isn't installed. ", \
    option_title_line1: "==================§bTPA §6Settings Menu§r==================", \
    option_title_line2: "Modify settings below: (Recall to see changes)", \
    option_button_enable: "[§aENABLE§r", \
    option_button_disable: "§cDISABLE§r]", \
    option_button_set: "[§aSET§r]", \
    option_debug_mode: "Debug Mode", \
    option_tp_spec: "If Allow Spectators to Teleport", \
    option_remove_offline: "If remove empty IDs after player offline", \
    option_carpet_fake_player_fix: "Carpet fake player fix", \
    option_back: "If disable back", \
    option_search_id: "If disable search ID", \
    option_book: "If disable tpa book", \
    option_player_lang: "If allow player language", \
    option_lang: "Server Language", \
    option_lang_hoverevent: "§bEnter Language selecting menu below", \
    option_home: "Homes a player can have", \
    option_home_hoverevent: "§bModify §aHome A Player Owns§r (§6Units: ones§r), §b 0 for disabling home, -1 for not restricting numbers of homes(Not Recommending)", \
    option_tp_pos: "Teleport position allow radius", \
    option_tp_pos_hoverevent: "§bModify §aTeleport Position Allow Radius§r (§6Units: meters§r), §b 0 for disabling teleport, -1 for not restrcting radius(Not Recommending)", \
    option_tp_pos_cooldown: "Teleport position cooldown", \
    option_tp_pos_cooldown_hoverevent: "§bModify §aCooldown Time§r (§6Units: 1 game tick = 1/20 seconds§r), §b 0 for no cooldown, -1 for disabling teleport", \
    option_time_out: "Teleport request timeout ", \
    option_time_out_hoverevent: "§bModify §aTeleport Request Timeout§r (§6Units: 1 game tick = 1/20 seconds§r), §b 0 for disabling teleport, -1 for never timeout", \
    option_idfix_cooldown: "ID fix cooldown", \
    option_idfix_cooldown_hoverevent: "§bModify §aID Fix Cooldown§r (§6Units: 1 game tick = 1/20 seconds§r), §b 0 for no cooldown, -1 for disabling ID fix", \
    option_frequency: "Data pack frequency", \
    option_frequency_hoverevent: "§bModify §aData Pack Frequency§r (§6Units: 1 game tick = 1/20 seconds§r), §b 0 for disabling data pack", \
    option_enabled: "§aENABLED§r", \
    option_disabled: "§cDISABLED§r", \
    option_button_uninstall: "[§4UNINSTALL§r]", \
    option_button_uninstall_hoverevent: "§4Click this button to §l§nUninstall§r§4 TPA datapack! Please consider if you really need it!", \
    option_button_update: "[§4UPDATE§r]", \
    option_button_update_hoverevent: "Click to start updating datapack", \
    option_button_license: "[§4LICENSE§r]", \
    option_button_license_hoverevent: "§bTo use TPA datapack, you must follow the open source license we put on Github website and the restrictions on §l§ncommercial§r§b use. Otherwise, a §6§lcopyright infringement§r§b risk will exist. So please read the whole text carefully.", \
    option_button_help: "[§4HELP§r]", \
    option_button_help_hoverevent: "Click to open help menu", \
    output_default: "You have changed the output position to §aBOTH CHATBAR AND ACTIONBAR§r", \
    output_hide_actionbar: "You have changed the output position to §bCHATBAR ONLY§r", \
    output_hide_chatbar: "You have changed the output position to §aACTIONBAR ONLY§r", \
    recver_accept_tpa_left_part: "You accepted", \
    recver_accept_tpa_hoverevent: "§bThe player who sent you a teleport request", \
    recver_accept_tpa_right_part: "'s teleport request", \
    recver_accept_tpahere_left_part: "You accepted to teleport you to", \
    recver_accept_tpahere_hoverevent: "§bPlayer whose §ltpahere§r request you have accepted ", \
    recver_accept_tpahere_right_part: "'s place.", \
    recver_accept_auto_left_part: "Have automatically accepted", \
    recver_accept_auto_hoverevent: "§bPlayer who sent you a teleport request", \
    recver_accept_auto_right_part: "'s teleport request'", \
    recver_accept_toggle_on: "You have enabled §aalways-accept§r", \
    recver_accept_toggle_off: "You have disabled §aalways-accept§r", \
    recver_cancel_left_part: "", \
    recver_cancel_hoverevent: "§bwho has canceled the request to you", \
    recver_cancel_right_part: "has cancelled the request to you", \
    recver_deny_tpa_left_part: "You denied", \
    recver_deny_tpa_hoverevent: "§bThe player who sent you a teleport request", \
    recver_deny_tpa_right_part: "'s teleport request", \
    recver_deny_tpahere_left_part: "You denied to teleport you to", \
    recver_deny_tpahere_hoverevent: "§bPlayer whose §ltpahere§r request you have denied ", \
    recver_deny_tpahere_right_part: "'s place.", \
    recver_recv_button_accept: "[§aACCEPT§r]", \
    recver_recv_button_accept_hoverevent: "§bClick to accept the request", \
    recver_recv_button_deny: "[§cDENY§r]", \
    recver_recv_button_deny_hoverevent: "§bClick to deny the request", \
    recver_recv_tpa_chatbar_left_part: "", \
    recver_recv_tpa_hoverevent: "§bThe player who sent you a teleport request", \
    recver_recv_tpa_chatbar_right_part: "sent you a teleport request", \
    recver_recv_tpa_actionbar_left_part: "", \
    recver_recv_tpa_actionbar_right_part: "sent you a teleport request. Nod 3 times to accept, shake head 3 times to deny.", \
    recver_recv_tpahere_hoverevent: "§bThe player who sent you a §ltpahere§r request", \
    recver_recv_tpahere_chatbar_right_part: "sent you a §ltpahere§r request", \
    recver_recv_tpahere_actionbar_right_part: "sent you a §ltpahere§r request. Nod 3 times to accept, shake head 3 times to deny.", \
    recver_req_not_exist: "No pending requests to process", \
    recver_timeout_hoverevent: "§bThe player whose request to you timed out", \
    recver_timeout_right_part: "'s teleport request timed out", \
    reqer_accept_tpa_left_part: "Teleporting to ", \
    reqer_accept_tpa_hoverevent: "§bThe player who accepted your teleport request", \
    reqer_accept_tpa_right_part: "...", \
    reqer_accept_tpahere_left_part: "Teleporting ", \
    reqer_accept_tpahere_hoverevent: "§bThe player who accepted your §ltpahere§r request", \
    reqer_accept_tpahere_right_part: "to you...", \
    reqer_accept_auto_left_part: "The player enabled always-accept, teleporting you to ", \
    reqer_accept_auto_hoverevent: "§bThe player who auto-accepted your teleport request", \
    reqer_accept_auto_right_part: "...", \
    reqer_button_tpa_hoverevent: "§bClick to send a teleport request to this player", \
    reqer_button_tpahere_hoverevent: "§bClick to request they teleport to your current location", \
    reqer_cancel_hoverevent: "§bThe player whose request you canceled", \
    reqer_cancel_right_part: "'s request", \
    reqer_cancel_spec: "Spectators cannot §acancel requests§r", \
    reqer_change_hoverevent: "§bThe player you previously sent a request to", \
    reqer_change_chatbar_middle_part: "'s request. The previous request was canceled. Sent a new request to ", \
    reqer_change_chatbar_right_part: ", waiting for acceptance", \
    reqer_change_actionbar_middle_part: "'s request. The previous request was canceled. Sent a new request to ", \
    reqer_change_actionbar_right_part: ", waiting for acceptance. Shake head 3 times to cancel", \
    reqer_deny_tpa_left_part: "Teleporting to ", \
    reqer_deny_tpa_hoverevent: "§bThe player who denied your teleport request", \
    reqer_deny_tpa_right_part: "...", \
    reqer_deny_tpahere_hoverevent: "§bThe player who denied your §ltpahere§r request", \
    reqer_deny_tpahere_right_part: "to you...", \
    reqer_recver_invalid: "Target offline or not teleportable", \
    reqer_disabled: "Server does not allow §ateleportation§r", \
    reqer_first_join: "[§6Click me to open TPA Menu§r]", \
    reqer_no_req_found: "You haven't sent any requests", \
    reqer_req_button_cancel_hoverevent: "§bClick to cancel the request", \
    reqer_req_hoverevent: "§bThe player you sent a request to", \
    reqer_req_tpa_hoverevent: "§bThe player you sent a teleport request to", \
    reqer_req_tpa_chatbar_right_part: "sent a teleport request. Waiting for acceptance", \
    reqer_req_tpa_actionbar_right_part: "sent a teleport request. Waiting for acceptance. Shake head 3 times to cancel", \
    reqer_req_tpahere_hoverevent: "§bThe player you sent a §ltpahere§r request to", \
    reqer_req_tpahere_chatbar_right_part: "sent a §ltpahere§r request. Waiting for acceptance", \
    reqer_req_tpahere_actionbar_right_part: "sent a §ltpahere§r request. Waiting for acceptance. Shake head 3 times to cancel", \
    reqer_req_not_exist: "The requested player does not exist or is offline", \
    reqer_self: "You cannot teleport to yourself", \
    reqer_spam: "You already sent a request to this player", \
    reqer_spec: "Spectators cannot §ateleport§r", \
    reqer_timeout_hoverevent: "§bThe player who did not accept your request", \
    reqer_timeout_right_part: "'s teleport request has expired", \
    search_id_disabled: "Server does not allow §aID search§r", \
    search_id_throw_on_invalid_char: "The name you entered contains invalid characters", \
    search_id_unavail_player: "Player is offline or cannot be teleported to", \
    simple_menu_disable: "Switched TPA menu to §adetailed mode§r", \
    simple_menu_enable: "Switched TPA menu to §asimple mode§r. You can now use §a/trigger tpa§r to open it", \
    simple_menu_title: "Click a player below to send a teleport request", \
    simple_menu_button_hoverevent: "§bClick to switch to detailed menu", \
    tp_pos_act_left_part: "Teleported you to position ", \
    tp_pos_act_right_part: "", \
    tp_pos_cooldown: "§aCoordinate teleport§r is on cooldown", \
    tp_pos_disabled: "Server does not allow §acoordinate teleport§r", \
    tp_pos_out_of_range: "Teleport distance exceeds server radius: ", \
    tp_pos_spec: "Spectators cannot §ateleport to coordinates§r", \
    tp_pos_throw_on_invalid_char: "The coordinates you entered contain invalid characters", \
    tpa_menu_hoverevent_left_part: "§bClick to send a teleport request to ", \
    tpa_menu_hoverevent_right_part: "", \
    tpa_menu_title: "Player usernames and datapack IDs. Click an ID to send a teleport request:                                       ", \
    tpahere_menu_title: "Player usernames and datapack IDs. Click an ID to send a §ltpahere§r request:                                       ", \
    tpa_menu_extend_hoverevent: "§bClick to expand menu", \
    tpa_menu_extend: "§bExpand§r", \
    tpa_menu_you: "You", \
    tpa_menu_has_id_of: "'s §adatapack ID§r is ", \
    tpa_menu_idfix_button_hoverevent: "§bUse this if multiple players share the same ID. This resets all player IDs.", \
    tpa_menu_search_id_button_hoverevent: "§bClick to open chat input for TPA commands", \
    tpa_menu_tpamenu_button_hoverevent: "§bClick to go to Teleport Menu", \
    tpa_menu_tpaheremenu_button_hoverevent: "§bClick to go to TPA Here Menu", \
    tpa_menu_back_button_hoverevent: "§bReturn to your position before teleporting", \
    tpa_menu_lang_button_hoverevent: "§bClick to switch language", \
    tpa_menu_book_button_hoverevent: "§bClick to get a TPA Book", \
    tpa_menu_pos_button_hoverevent: "§bClick to open chat input for coordinate teleport", \
    tpa_menu_here_button_hoverevent: "§bClick to broadcast your position", \
    tpa_menu_home_button_hoverevent: "§bClick to open Home menu", \
    tpa_menu_auto_accept: "Auto-accept: ", \
    tpa_menu_mute: "Mute datapack: ", \
    tpa_menu_output: "Output display: ", \
    tpa_menu_output_default: "[§bDefault§r", \
    tpa_menu_output_actionbar: "§bHide chat§r", \
    tpa_menu_output_chatbar: "§bHide action bar§r]", \
    tpa_menu_enable: "[§aEnable§r", \
    tpa_menu_disable: "§cDisable§r]", \
    tpa_menu_refresh_hoverevent: "§bClick to refresh or reopen the TPA menu", \
    tpa_menu_simplemenu_button_hoverevent: "§bSwitch to simple menu", \
    tick_not_working_cmdblk_name: "§r§bPlace this in a valid location", \
    header: "[§bTPA§r] ", \
    book_check_missing: "Detected missing teleport book, reissued.", \
    book_incompatible: "§aTeleport Book§r is incompatible with this game version", \
    book_refresh: "You refreshed the §aTeleport Menu Book§r", \
    book_reget: "[§bReget§r]", \
    book_reget_hoverevent: "§bClick to reget the teleport book", \
    book_stacking: "Detected stacked teleport books, extra copies have been removed", \
    dimension_menu_button: "[§bDimension Settings Menu§r]", \
    dimension_menu_button_hoverevent: "§bClick to configure dimensions", \
    dimension_overworld: "Overworld", \
    dimension_the_nether: "Nether", \
    dimension_the_end: "The End", \
    dimension_unknown: "Unknown Dimension", \
    dimension_unknown_detected_leftpart: "Unknown dimension detected (", \
    dimension_unknown_detected_rightpart: "), please configure it in the dimension menu: ", \
    extended_menu_incompatible: "§aExtended menu§r is incompatible with this game version", \
    here_button_tpa_notavail_hoverevent: "§cThis player does not allow teleporting", \
    hoverevent_suggest_tip: "§aYou should complete the command as: ", \
    load_date_check_left_part: "Current version was released on", \
    load_date_check_right_part: ", please pay attention to updates", \
    load_done_extra: " Extra version ", \
    load_date_check_format: 231, \
    load_date_check_format_comment: "§r§l§n# 1 for year, 2 for month, 3 for day, '123' here means the format is Year-Month-Day", \
    load_date_check_year_prefix: "", \
    load_date_check_year_suffix: "", \
    load_date_check_year_local_prefix: "", \
    load_date_check_year_local_suffix: "", \
    load_date_check_month_prefix: "", \
    load_date_check_month_suffix: "/", \
    load_date_check_day_prefix: "", \
    load_date_check_day_suffix: "/", \
    option_advenced_warn: "The following settings are advanced options. Do not modify unless you know what you are doing.", \
    option_advenced_tip: "Enable debug mode to access more advanced settings", \
    option_anchor_search_retries: "Anchor search retry count", \
    option_anchor_search_retries_hoverevent: "§bModify the number of anchor search retries below §r(§6Units:                         times §ror §6game ticks / frequency§r). §bToo high may increase wait time, too low may cause misdetection or data pollution.", \
    option_button_notworking: "[§4Not Working§r]", \
    option_button_notworking_hoverevent: "§bClick when tick function does not work (TPA menu cannot be opened)", \
    option_carpet_fake_player_fix_incompatible: "Carpet fake player fix is incompatible with this version", \
    option_compact_ids: "Remove empty ID slots after player logout", \
    option_current_game_version: "Detected game version", \
    option_debug_mode_hoverevent: "§bClick below to enable debug mode. This will provide debug information in chat, but may cause spam. Reopen the settings menu after enabling to access advanced options.", \
    option_dimension: "Compatible Dimensions", \
    option_dimension_button_add: "[§aAdd§r]", \
    option_dimension_button_add_hoverevent: "§bClick to add a new dimension", \
    option_dimension_button_edit_color: "[§aEdit Color§r]", \
    option_dimension_button_edit_color_hoverevent: "§bClick to edit this dimension's theme color (enter vanilla 16-color name or #XXXXXX hex code)", \
    option_dimension_button_edit_id: "[§aEdit Dimension ID§r]", \
    option_dimension_button_edit_id_hoverevent: "§bClick to edit the dimension ID (press Left Arrow, then enter after colon)", \
    option_dimension_button_edit_namespaceid: "[§aEdit Namespace ID§r]", \
    option_dimension_button_edit_namespaceid_hoverevent: "§bClick to edit namespace ID (namespace:                        id). Press Left Arrow twice and type inside quotes.", \
    option_dimension_button_edit_name: "[§aEdit Name§r]", \
    option_dimension_button_edit_name_hoverevent: "§bClick to edit display name. Vanilla dimensions follow language settings.", \
    option_dimension_button_remove: "[§cRemove§r]", \
    option_dimension_button_remove_hoverevent: "§bClick to remove this dimension", \
    option_dimension_button_remove_notavail_hoverevent: "§cVanilla dimensions cannot be removed", \
    option_dimension_hoverevent: "§bOpen the dimension compatibility menu below", \
    option_dimension_menu_title: "The server supports the following dimensions: ", \
    option_dimension_number_hoverevent_leftpart: "§bThe server currently supports ", \
    option_dimension_number_hoverevent_rightpart: " dimensions", \
    option_server_calling: "Qing3 shi3yong4 Ke4hu4duan1, er2 bu2shi4 Kong4zhi4tai2 lai2 tiao2zheng3 she4zhi4!", \
    recver_recv_tpahere_actionbar_left_part: "", \
    recver_recv_tpahere_chatbar_left_part: "", \
    recver_timeout_left_part: "", \
    reqer_button_tpa: "[§bTeleport§r]", \
    reqer_button_tpahere: "[§bTeleport Here§r]", \
    reqer_cancel_left_part: "You canceled the request to ", \
    reqer_change_actionbar_left_part: "You previously sent a request to ", \
    reqer_change_chatbar_left_part: "You previously sent a request to ", \
    reqer_req_button_cancel: "[§4Cancel§r]", \
    reqer_req_tpa_actionbar_left_part: "You sent a request to ", \
    reqer_req_tpa_chatbar_left_part: "You sent a request to ", \
    reqer_req_tpahere_actionbar_left_part: "You sent a request to ", \
    reqer_req_tpahere_chatbar_left_part: "You sent a request to ", \
    reqer_timeout_left_part: "Your request to ", \
    search_id_abort: "You stopped §asearching player IDs§r", \
    search_id_dialog_done_tooltip: "§bClick to submit name", \
    search_id_dialog_cancel: "Cancel", \
    search_id_dialog_cancel_tooltip: "§bClick to cancel input", \
    search_id_incompatible: "§aSearch Player ID§r is incompatible with this game version", \
    search_id_keyboard_title: "Click the keyboard buttons below to input player name: ", \
    search_id_name_input: "Input: ", \
    search_id_recall: "[§bRecall§r]", \
    search_id_recall_hoverevent: "§bRecall search player ID keyboard", \
    teleport_anchor_actionbar: "Anchor teleport progress: ", \
    teleport_binary_actionbar: "Binary search teleport progress: ", \
    teleport_cal_sim_dist_actionbar: "Simulation distance", \
    teleport_cal_sim_dist_end_leftpart: "Simulation distance calculated successfully. Current datapack simulation distance is:                         ", \
    teleport_cal_sim_dist_start: "Simulation distance calculation started", \
    teleport_sim_dist_warn: "Server simulation distance is not set. Attempting to teleport non-player targets. If teleport fails, please contact admin to recalculate or manually set, or use binary teleport.", \
    teleport_sim_dist_warn_button_calc: "[§aCalculate§r]", \
    teleport_sim_dist_warn_button_binary: "[§aBinary Search§r]", \
    teleport_sim_dist_warn_button_binary_hoverevent: "§b点击将传送方式设置为二分法传送", \
    tick_not_working_button_set_schedule: "§b[设置]", \
    tick_not_working_button_set_schedule_hoverevent: "§b点击设置/schedule指令调用Tick函数", \
    tick_not_working_server_calling: "Qing3 shi3yong4 Ke4hu4duan1, er2 bu2shi4 Kong4zhi4tai2 lai2 huo4qu3 Ming4ling4fang1kuai4!", \
    tp_pos_abort: "You stopped entering teleport coordinates", \
    uninstall_start: "Uninstalling... (0/2)", \
    uninstall_rmv_objs: "移除所有记分项... (0/2)", \
    uninstall_rmv_done_1: "成功移除. (1/2)", \
    uninstall_rmv_tags: "正在移除所有标签... (1/2)", \
    uninstall_rmv_done_2: "成功移除. (2/2)", \
    uninstall_done_leftpart: "§aSuccessfully uninstalled. Use ", \
    update_step1_leftpart: "You are updating the TPA datapack. Current installed version is ", \
    warp_slot_disabled_leftpart: "The warp you accessed", \
    warp_slot_disabled_rightpart: "has been disabled", \
    warp_teleport_left_part: "You have been teleported to ", \
    warp_teleport_right_part: "", \
    reqer_deny_tpahere_left_part: "The requestor is denied from teleporting here.", \
    option_game_version: "The compatible game version for the datapack file", \
    option_max_anchor_summons_attempts: "Maximum summon attempts for teleportation anchor", \
    option_max_anchor_summons_attempts_hoverevent: "§bChange the §aMaximum summon attempts for teleportation anchor §r(§6Unit:                attempts§r)   §bSetting it too high may cause lag and unnecessary waiting, setting it too low may cause frequent teleportation failures.", \
    option_sim_dist: "Simulation distance", \
    option_sim_dist_button_cal: "[§aCalculate§r]", \
    option_sim_dist_hoverevent: "§bChange the §aSimulation distance §r(§6Unit: chunks§r)  Please make sure there are no players within the simulation distance from the origin in the overworld before clicking.", \
    option_stricter_book_check: "Stricter teleportation book check", \
    option_stricter_book_check_incompatible: "Stricter teleportation book check is incompatible with this version", \
    option_stricter_book_check_disabled: "This feature requires the Bookshelf datapack as a dependency, but the server has not installed the Bookshelf datapack.", \
    option_server_calling_comment: "§l§n§4This is a comment because the option_server_calling above needs to be displayed to the console. If written directly in Chinese, it will appear as garbled text. This uses Pinyin for representation.", \
    option_uses_binary_teleport: "Use binary teleportation?", \
    option_uses_binary_teleport_hoverevent: "§bChoose §aBinary teleportation (enabled) §6or §cAnchor teleportation (disabled)", \
    option_uses_string_dimension: "Recognize string dimensions?", \
    option_uses_string_dimension_hoverevent: "§bChoose §aUse strings for dimension storage (1.16+ enabled) §6or §cUse integers for dimension storage (1.16- disabled)", \
    option_version: "Datapack version", \
    option_warp: "Public teleport points", \
    option_warp_hoverevent: "§bClick below to open the §aPublic teleport point §6menu, the number on the right indicates the number of public teleport points currently set.", \
    option_warp_number_hoverevent_leftpart: "§bThe server currently has ", \
    option_warp_number_hoverevent_rightpart: "§b public teleport points.", \
    option_uses_tick_scheduling: "Use /schedule command to call the Tick function", \
    simple_menu_button: "[§bDetailed menu§r]", \
    simple_menu_incompatible: "§aSimplified menu§r is not compatible with this game version", \
    teleport_cal_sim_dist_end_rightpart: "", \
    teleport_incompatible: "§aAnchor teleportation§r is not compatible with this game version", \
    teleport_sim_dist_disabled: "The server has not set the simulation distance", \
    teleport_sim_dist_warn_button_calc_hoverevent: "§bClick to start automatically calculating simulation distance. §cWarning:                This operation may teleport the executor to a different location. Please make sure your position doesn’t need to remain loaded before clicking.", \
    tick_not_working_server_calling_comment: "§l§n§cThis is a comment because the tick_not_working_server_calling above needs to be displayed to the console. If written directly in Chinese, it will appear as garbled text. This uses Pinyin for representation.", \
    tick_not_working_tips_line1: "You are currently calling a Tick function that doesn't work, so you may have encountered an issue where the Tick function doesn't work. You can implement one of the following two methods:               ", \
    tick_not_working_tips_line2: "        1. Use the /schedule command to call the Tick function.", \
    tick_not_working_tips_line3: "   Or 2. Place your command block in a hidden location to avoid being destroyed by Bedrock-breaking machines.", \
    tp_pos_button_abort: "[Abort]", \
    tp_pos_button_teleport: "[Teleport]", \
    tp_pos_dialog_cancel_tooltip: "§bClick to cancel input", \
    tp_pos_dialog_done_tooltip: "§bClick to submit the set teleport coordinates", \
    tp_pos_dialog_set: "Current: ", \
    tp_pos_dialog_set_x: "Set X coordinate", \
    tp_pos_dialog_set_x_tooltip: "§bClick to set the X coordinate", \
    tp_pos_dialog_set_y: "Set Y coordinate", \
    tp_pos_dialog_set_y_tooltip: "§bClick to set the Y coordinate", \
    tp_pos_dialog_set_z: "Set Z coordinate", \
    tp_pos_dialog_set_z_tooltip: "§bClick to set the Z coordinate", \
    tp_pos_recall: "[§bRecall§r]", \
    tp_pos_recall_hoverevent: "§bClick to recall the teleport coordinates menu", \
    tp_pos_title: "Adjust coordinates below: ", \
    tpa_menu_back_button: "[§bBack to previous position§r]", \
    tpa_menu_book_button: "[§bGet teleportation book§r]", \
    tpa_menu_dialog: "[§bDialog menu§r]", \
    tpa_menu_dialog_title: "§bTPA menu", \
    tpa_menu_dialog_hoverevent: "§bClick to open the dialog menu", \
    tpa_menu_switch_hoverevent: "§bClick to switch", \
    tpa_menu_disabled: "§cDisabled", \
    tpa_menu_disabled_hoverevent: "§bClick to switch to §aEnabled", \
    tpa_menu_enabled: "§aEnabled", \
    tpa_menu_enabled_hoverevent: "§bClick to switch to §cDisabled", \
    tpa_menu_has_id_of_hoverevent: "§bThe internal player ID assigned to each player for correspondence", \
    tpa_menu_here_button: "[§bBroadcast position§r]", \
    tpa_menu_home_button: "[§bHome menu§r]", \
    tpa_menu_warp_button: "[§bLandmark menu§r]", \
    tpa_menu_warp_button_hoverevent: "§bClick to open the public teleport point (landmark) menu", \
    tpa_menu_idfix_button: "[§bID fix§r]", \
    tpa_menu_lang_button: "[§bSwitch language§r]", \
    tpa_menu_output_actionbar_hidden: "§bOnly action bar§r", \
    tpa_menu_output_chatbar_hidden: "§bOnly chat bar§r", \
    tpa_menu_output_no_hidden: "§bBoth action and chat bar§r", \
    tpa_menu_pos_button: "[§bTeleport coordinates§r]", \
    tpa_menu_refresh: "[§6Refresh TPA menu§r]", \
    tpa_menu_search_id_button: "[§bSearch player§r]", \
    tpa_menu_simplemenu_button: "[§bSimplified menu§r]", \
    tpa_menu_tpaheremenu_button: "[§bTeleport here menu§r]", \
    tpa_menu_tpamenu_button: "[§bTeleport menu§r]", \
    uninstall_done_hoverevent: "Click to run command", \
    uninstall_done_rightpart: "To enable it again", \
    update_reload: "§b[Reload]", \
    update_reload_hoverevent: "Click to reload", \
    update_step1_rightpart: " Please confirm to begin updating here.", \
    update_step1_button: "§b§n§l[I'm sure of what I'm doing]", \
    update_step1_hoverevent: "Please click carefully", \
    update_step2: "Please download the latest version of the datapack from GitHub, QQ group, or Modrinth as a backup.", \
    update_step3: "Please click the button on the right to temporarily disable the datapack for the next installation step.", \
    update_step3_button: "§b[Disable datapack]", \
    update_step3_hoverevent: "If you can’t disable it, please check if the datapack’s file name is correct.", \
    update_step4: "We're almost done, please drag the datapack file into the datapacks folder and unzip it, then delete the old datapack.", \
    update_step5_leftright: "Afterwards, we’ve completed the installation of the TPA datapack. If everything works, start adjusting the datapack settings. If it didn’t load correctly, please try.", \
    update_step5_button: "§b[Load]", \
    update_step5_hoverevent: "Click to load the datapack", \
    update_step5_rightpart: " If unknown scoreboard items appear, please start from step 3. This may be caused by incorrect version or unknown issues. For other issues, please consult Xiao_tu233.", \
    update_nextstep: "§b[Next step]", \
    warp_button_add: "[§aCreate new teleport point§r]", \
    warp_button_add_hoverevent: "§bClick to create a new public teleport point at your current location", \
    warp_button_apply: "[§aApply§r]", \
    warp_button_apply_hoverevent: "§bClick to apply the cached changes", \
    warp_button_cancel: "[§cCancel§r]", \
    warp_button_cancel_hoverevent: "§bClick to discard the cached changes", \
    warp_button_enable: "[§aEnable§r]", \
    warp_button_enable_hoverevent: "§bClick to enable this public teleport point", \
    warp_button_disable: "[§cDisable§r]", \
    warp_button_disable_hoverevent: "§bClick to disable this public teleport point (except for name, other information will be hidden, enable to view)", \
    warp_button_moveup: "[§dMove up§r]", \
    warp_button_moveup_hoverevent: "§bClick to swap this public teleport spot with the one above", \
    warp_button_moveup_notavail_hoverevent: "§cCannot move up, this teleport spot is already at the top", \
    warp_button_movedown: "[§dMove Down§r]", \
    warp_button_movedown_hoverevent: "§bClick to swap this public teleport spot with the one below", \
    warp_button_tp: "[§bTeleport§r]", \
    warp_button_tp_hoverevent: "§bClick to teleport to this public teleport spot", \
    warp_button_rm: "[§cRemove§r]", \
    warp_button_rm_hoverevent: "§bClick to remove this public teleport spot", \
    warp_button_select: "[§aSelect§r]", \
    warp_button_select_hoverevent: "§bClick to select this public teleport spot slot to write changes when applying", \
    warp_button_unselect: "[§cUnselect§r]", \
    warp_button_unselect_hoverevent: "§bClick to unselect this public teleport spot slot", \
    warp_button_setdesc: "[§aSet Description§r]", \
    warp_button_setdesc_hoverevent: "§bClick to set the description of this public teleport spot (after clicking, press the left arrow key on your keyboard, enter the description within quotes, then press Enter)", \
    warp_button_setname: "[§aSet Name§r]", \
    warp_button_setname_hoverevent: "§bClick to set the name of this public teleport spot (after clicking, press the left arrow key on your keyboard, enter the name within quotes, then press Enter)", \
    warp_button_setpos: "[§aSet Position§r]", \
    warp_button_setpos_hoverevent: "§bClick to set this public teleport spot to your current position", \
    warp_desc_disabled: "§cThis public teleport spot is disabled", \
    warp_disabled: "§aPublic teleport spot§r has been disabled by the server", \
    warp_menu_title: "The server has set the following public teleport spots: ", \
    warp_menu_edit_tip: "You are currently in edit mode. Select the operation slot below by index, then modify specific data using the buttons below. Finally, click Apply to apply the changes", \
    warp_number: "Public Teleport Spot #", \
    warp_out_of_range: "This public teleport spot has not been set yet", \
    warp_select_left_part: "You have selected", \
    warp_select_right_part: "as the slot being edited", \
    warp_set_left_part: "You have set", \
    warp_set_middle_part: "to", \
    warp_set_position: "coordinates", \
    warp_set_right_part: "", \
    warp_set_default_name: "Unnamed Teleport Spot", \
    warp_spec: "Spectator mode players are not allowed to teleport to §aPublic Teleport Spot§r" \
}, \
  {\
    lang: "ja_jp", \
    id: 4, \
    name: "ja_jp", \
    name_display: "日本語（日本）", \
    header: "[§bTPA§r] ", \
    back_act: "前の位置にテレポートしました", \
    back_disabled: "§a前の位置に戻り§rはサーバーで無効になっています", \
    back_not_exist: "前の位置を見つかりしませんでした", \
    back_spec: "スペクテイターモードのプレーヤーは§a前の位置§r戻れません", \
    book_check_missing: "TPAの本が失われたため、再度付与しました", \
    book_disabled: "§aTPAの本§rはサーバーで無効になっています", \
    book_incompatible: "§aTPAの本§rはこのゲームバージョンと互換性がありません", \
    book_lore: "§r§b右クリックでTPAメニューを開く。捨てるとリフレッシュ。オフハンドに持ち替えると使用停止。", \
    book_mainhand_busy: "メインハンドにアイテムを持っているため、TPAの本を受け取れません", \
    load_date_check_format: 123, \
    load_date_check_format_comment: "§r§l§n# 1 for year, 2 for month, 3 for day, '123' here means the format is Year-Month-Day", \
    load_date_check_year_prefix: "", \
    load_date_check_year_suffix: "年", \
    load_date_check_year_local_prefix: "(令和", \
    load_date_check_year_local_suffix: "年)", \
    load_date_check_month_prefix: "", \
    load_date_check_month_suffix: "月", \
    load_date_check_day_prefix: "", \
    load_date_check_day_suffix: "日", \
    book_refresh: "§a転送メニューの本をリフレッシュしました", \
    book_reget: "[§b再取得§r]", \
    book_reget_hoverevent: "§bクリックして転送本を再取得", \
    book_spec: "観客モードのプレイヤーは§a転送本§rを使用できません", \
    book_stacking: "転送本がスタックされていることを検出しました、余分な本は没収されました", \
    book_stop: "§a転送本§rの使用を停止しました。TPAメニューで再取得できます", \
    book_title: "§r§b転送メニューの本 §a[投げてリフレッシュ] ", \
    dimension_menu_button: "[§b次元設定メニュー§r]", \
    dimension_menu_button_hoverevent: "§bクリックして次元設定を変更", \
    dimension_overworld: "オーバーワールド", \
    dimension_the_nether: "ネザー", \
    dimension_the_end: "エンド", \
    dimension_unknown: "不明な次元", \
    dimension_unknown_detected_leftpart: "不明な次元を検出しました(", \
    dimension_unknown_detected_rightpart: "), 次元メニューで設定してください: ", \
    extended_menu_incompatible: "§a展開メニュー§rはこのゲームバージョンと互換性がありません", \
    extended_menu_next_page: "§b次のページを見る", \
    extended_menu_previous_page: "§b前のページを見る", \
    extended_menu_title: "======================§bTPA§6 メニュー§r========================", \
    here_button_tpa: "[§b転送リクエスト§r]", \
    here_button_tpa_hoverevent: "§bクリックして転送リクエストを送信", \
    here_button_tpa_notavail_hoverevent: "§cプレイヤーは転送を許可していません", \
    here_spec: "観客モードのプレイヤーは§a位置をブロードキャスト§rできません", \
    here_voxel_hoverevent: "§bクリックしてVoxelMapのパスを追加", \
    here_xaero_hoverevent: "§6クリックしてXearo's Minimapのパスを追加", \
    home_act_left_part: "転送先#に転送しました", \
    home_act_right_part: "", \
    home_create: "転送点がまだ設定されていません", \
    home_create_button: "[§a新しく設定§r]", \
    home_create_button_hoverevent: "§aクリックして転送点を設定", \
    home_disabled: "§a転送点§rはサーバーで無効化されています", \
    home_display: "§b転送点#", \
    home_display_rm_button: "[§c削除§r]", \
    home_display_rm_button_hoverevent: "§cクリックしてこの転送点を削除", \
    home_display_set_button: "[§a設定§r]", \
    home_display_set_button_hoverevent: "§aクリックして転送点を設定", \
    home_display_tp_button: "[§b転送§r]", \
    home_display_tp_button_hoverevent: "§bクリックしてこの転送点に転送", \
    home_menu_title: "現在、次の転送点スロットがあります: ", \
    home_missing_hoverevent: "この転送点はまだ設定されていません", \
    home_new: "§a新しく設定: ", \
    home_not_found_hoverevent: "アクセスした転送点", \
    home_not_found_left_part: "アクセスした転送点#", \
    home_not_found_right_part: "が存在しません", \
    home_number: "転送点#", \
    home_out_of_range_left_part: "アクセスした転送点#", \
    home_out_of_range_right_part: "がサーバーの制限を超えています", \
    home_remove_hoverevent: "§b削除された転送点", \
    home_remove_left_part: "転送点#を削除しました", \
    home_remove_right_part: "", \
    home_set_left_part: "転送点#を", \
    home_set_middle_part: "設定しました", \
    home_set_position: "位置", \
    home_set_right_part: "", \
    home_spec: "観客モードのプレイヤーは§a転送点§rを操作できません", \
    hoverevent_suggest_tip: "§aこのコマンドを補完してください: ", \
    idfix_act_hoverevent: "§bこのプレイヤーはID修復を使用しました", \
    idfix_act_left_part: "", \
    idfix_act_right_part: "§aID修復§rを使用し、全プレイヤーのデータ番号と前回位置がリセットされました", \
    idfix_cooldown: "§aID修復§rはまだクールダウン中です", \
    idfix_disabled: "§aID修復§rはサーバーで無効化されています", \
    lang_button: "[§6ここをクリックして言語を選択§r]", \
    lang_button_hoverevent: "§bクリックして言語メニューを表示", \
    lang_button_server: "[§6ここをクリックしてサーバー言語を選択§r]", \
    lang_disabled: "§aプレイヤーによる言語選択§rはサーバーで無効化されています", \
    lang_menu_select_button: "[§a推奨コマンドをロード§r]", \
    lang_menu_select_button_hoverevent: "§bクリックしてチャットに推奨コマンドをロード: ", \
    lang_menu_title: "下から言語を選択してください:", \
    lang_selected_left_part: "言語を切り替えました:", \
    lang_selected_right_part: "", \
    lang_server_follow_left_part: "サーバーパックのデフォルト言語が設定されていないため、現在", \
    lang_server_follow_right_part: "に設定されています", \
    load_add_objectives: "46個のスコア項目を追加中... (1/6)", \
    load_added_objectives: "スコア項目を正常に追加しました... (2/6)", \
    load_author: "このデータパックは§6Xiao_tu233§rによって作成されました。", \
    load_button_help: "[ヘルプ]", \
    load_button_help_hoverevent: "クリックしてヘルプを表示", \
    load_button_license: "[ライセンス]", \
    load_button_license_hoverevent: "§bTPAデータパックを使用する際は、GitHubで公開されているライセンスに従ってください。 §bまた、作者§l§nはこのデータパックを§r§b商用サーバーで使用することを推奨していません。 §b誤解を避けるため、使用前にライセンス全文をよく読んで理解してください。", \
    load_button_options: "[設定]", \
    load_button_options_hoverevent: "クリックしてデータパック設定を変更", \
    load_button_update: "[更新]", \
    load_button_update_hoverevent: "クリックしてデータパック更新ガイドを開始", \
    load_copyright_claim: "Copyright © 2024-2026 Xiao_tu233. このデータパックはGPL-3.0オープンソースライセンスに従っています。 オープンソースプロジェクトですが、作者は商用サーバーでの使用を推奨していません。[ライセンス]をクリックしてライセンス全文を確認できます。", \
    load_date_check_left_part: "現在のバージョンは", \
    load_date_check_right_part: "にリリースされました。アップデートに注意してください", \
    load_did_reset_scores: "オンラインプレイヤーのスコアを正常にリセットしました... (3/6)", \
    load_done: "§aデータパックのリロードが完了しました: ", \
    load_done_extra: " 完全版 ", \
    load_init_storage: "関連コマンドストレージを初期化中... (3/6)", \
    load_init_vars: "変数を初期化中... (5/6)", \
    load_initted_storage: "関連コマンドストレージを正常に初期化しました... (4/6)", \
    load_initted_vars: "変数を正常に初期化しました... (6/6)", \
    load_remove_tags: "タグを削除中... (4/6)", \
    load_removed_tags: "タグを正常に削除しました... (5/6)", \
    load_reset_scores: " オンラインプレイヤーのスコアをリセット中... (2/6)", \
    load_title: "§eリロード中...", \
    load_version_hoverevent: "§bこれはTPAデータパックのバージョンであり、Minecraftのバージョンではありません。", \
    load_welcome: "TPAデータパックへようこそ！", \
    mute_disable: "§aデータパックのサウンド§rを有効にしました", \
    mute_enable: "データパックを§aミュート§rしました", \
    option_advenced_warn: "以下は高度な設定です。内容を理解していない場合は変更しないでください", \
    option_advenced_tip: "デバッグモードをオンにすると、さらに多くの設定を調整できます（高度設定）", \
    option_anchor_search_retries: "テレポートアンカー探索の再試行回数", \
    option_anchor_search_retries_hoverevent: "§b以下で§aテレポートアンカー探索の再試行回数を変更§r(§6単位: 回§rまたは§6ティック/実行頻度§r)、§b値が大きすぎると待機時間が長くなり、小さすぎるとアンカー誤認や汚染が発生する可能性があります", \
    option_back: "プレイヤーの前回位置への戻りを禁止", \
    option_book: "テレポートブックの使用を禁止", \
    option_button_disable: "§c無効§r]", \
    option_button_enable: "§r[§a有効§r", \
    option_button_help: "[§4ヘルプ§r]", \
    option_button_help_hoverevent: "§bクリックしてヘルプメニューを開く", \
    option_button_license: "[§4ライセンス§r]", \
    option_button_license_hoverevent: "§bTPAデータパックを使用する際は、GitHub上のオープンソースライセンスに従ってください。§bまた、作者§l§nは商用サーバーでの使用を推奨していません。§b誤解を避けるため、使用前にライセンス内容をよく読んで理解してください。", \
    option_button_notworking: "[§4動作不可§r]", \
    option_button_notworking_hoverevent: "§bTick関数が動作しない場合（TPAメニューが開かない場合）はクリックしてください", \
    option_button_set: "§r[§a設定§r]", \
    option_button_uninstall: "[§4アンインストール§r]", \
    option_button_uninstall_hoverevent: "§4クリックして§l§nTPAデータパックをアンインストール§r§4します！本当に必要か確認してください！", \
    option_button_update: "[§4アップデート§r]", \
    option_button_update_hoverevent: "§bクリックしてデータパックの更新を開始", \
    option_carpet_disabled: "この機能はCarpetモジュールが必要ですが、サーバーにはCarpetモジュールがインストールされていません。", \
    option_carpet_fake_player_fix: "Carpetモジュールのフェイクプレイヤー修正", \
    option_carpet_fake_player_fix_incompatible: "このバージョンではCarpetモジュールのフェイクプレイヤー修正は互換性がありません", \
    option_compact_ids: "プレイヤーがオフライン時にIDの空き番号を削除するか", \
    option_current_game_version: "現在検出されたゲームバージョン", \
    option_debug_mode: "デバッグモード", \
    option_debug_mode_hoverevent: "§b下をクリックしてデバッグモードを有効化§r。チャットに問題解決用情報を表示しますが、画面が流れる可能性があります。有効化後に再度設定メニューを開くと高度設定を調整できます", \
    option_dimension: "対応済みディメンション", \
    option_dimension_button_add: "[§a追加§r]", \
    option_dimension_button_add_hoverevent: "§bクリックして新しいディメンションを追加", \
    option_dimension_button_edit_color: "[§a色を編集§r]", \
    option_dimension_button_edit_color_hoverevent: "§bクリックしてディメンションのテーマカラーを編集（クリック後、コマンド末尾に16色英語または#XXXXXX形式で入力しEnter）", \
    option_dimension_button_edit_id: "[§aディメンションIDを編集§r]", \
    option_dimension_button_edit_id_hoverevent: "§bクリックしてディメンションIDを編集（クリック後、左矢印キーを押してコロンの後に入力しEnter）", \
    option_dimension_button_edit_namespaceid: "[§aネームスペースIDを編集§r]", \
    option_dimension_button_edit_namespaceid_hoverevent: "§bクリックしてディメンションのネームスペースIDを編集(namespace:id, source location 例:                minecraft:xxx)(クリック後、左矢印キーを2回押して引用符内に入力しEnter)", \
    option_dimension_button_edit_name: "[§a名前を編集§r]", \
    option_dimension_button_edit_name_hoverevent: "§bクリックしてディメンションの表示名を編集（クリック後、左矢印キーを2回押して引用符内に入力しEnter。原版ディメンションは言語設定に従います）", \
    option_dimension_button_remove: "[§c削除§r]", \
    option_dimension_button_remove_hoverevent: "§bクリックしてディメンションを削除", \
    option_dimension_button_remove_notavail_hoverevent: "§c原版ディメンションは削除できません", \
    option_dimension_hoverevent: "§b以下のボタンで§aディメンション互換§6メニューを開く§b右の数字は現在対応済みディメンション数", \
    option_dimension_menu_title: "サーバーが対応しているディメンション: ", \
    option_dimension_number_hoverevent_leftpart: "§bサーバーが現在対応しているディメンション数: ", \
    option_dimension_number_hoverevent_rightpart: " 個", \
    option_disabled: "§c無効§r", \
    option_enabled: "§a有効§r", \
    option_frequency: "データパック実行頻度", \
    option_frequency_hoverevent: "§b以下で§aデータパック実行頻度を変更§r(§6単位: 1ティック=1/20秒§r)、§b無効化をクリックするとデータパックの動作を一時停止できます", \
    option_game_version: "データパックファイル対応ゲームバージョン", \
    option_home: "所有するホーム数", \
    option_home_hoverevent: "§b以下で§aホーム数を変更§r(§6単位: 個§r)、§b0でホーム禁止、§b-1で制限なし（非推奨）", \
    option_idfix_cooldown: "§bID修復クールダウン", \
    option_idfix_cooldown_hoverevent: "§b以下で§aID修復クールダウンを変更§r(§6単位: 1ティック=1/20秒§r)、§b0でクールダウンなし、§b-1でID修復禁止", \
    option_lang: "サーバー言語", \
    option_lang_hoverevent: "§b以下で言語選択メニューを開く", \
    option_player_lang: "プレイヤーの言語選択を許可するか", \
    option_max_anchor_summons_attempts: "テレポートアンカー最大召喚試行回数", \
    option_max_anchor_summons_attempts_hoverevent: "§b以下で§aテレポートアンカー最大召喚試行回数を変更§r(§6単位: 回§r)、§b値が大きすぎるとラグと無駄な待機が増え、小さすぎるとテレポート失敗が多発する可能性があります", \
    option_search_id: "プレイヤーID検索を無効にするか", \
    option_sim_dist: "シミュレーション距離", \
    option_sim_dist_button_cal: "[§a計算§r]", \
    option_sim_dist_hoverevent: "§b以下で§aシミュレーション距離を変更§r(§6単位: チャンク§r)、主世界の原点にプレイヤーがいないことを確認してからクリックしてください", \
    option_stricter_book_check: "テレポートブックのより厳密なチェック", \
    option_stricter_book_check_incompatible: "このバージョンでは厳密なテレポートブックチェックは互換性がありません", \
    option_stricter_book_check_disabled: "この機能にはBookshelfデータパックが必要ですが、サーバーにはインストールされていません。", \
    option_time_out: "テレポートリクエストのタイムアウト時間", \
    option_time_out_hoverevent: "§b以下で§aテレポートリクエストのタイムアウト時間を変更§r(§6単位: 1ティック=1/20秒§r)、§b0で禁止、§b-1で無限", \
    option_title_line1: "======================§bTPA§6 設定メニュー§r=====================", \
    option_title_line2: "以下で設定を調整してください: (変更を確認するにはメニューを再度開く必要があります)", \
    option_tp_pos: "テレポート座標許可範囲", \
    option_tp_pos_cooldown: "テレポート座標クールダウン時間", \
    option_tp_pos_cooldown_hoverevent: "§b以下で§aクールダウン時間を変更§r(§6単位: 1ゲームティック = 1/20秒§r), §b0を入力するとクールダウン無し, §b-1を入力するとテレポート禁止", \
    option_tp_pos_hoverevent: "§b以下で§aテレポート座標許可範囲を変更§r(§6単位: メートル§r), §b0でテレポート禁止, §b-1で範囲無制限(非推奨)", \
    option_tp_spec: "観戦者のテレポートを許可", \
    option_server_calling: "クライアントから呼び出してください。コンソールからではありません！", \
    option_server_calling_comment: "§l§n§4これはコメントです。option_server_callingはコンソールで表示する必要があります。漢字を直接書くと文字化けするため、ここではピンインを使用しています。", \
    option_uses_binary_teleport: "二分法テレポートを使用するか", \
    option_uses_binary_teleport_hoverevent: "§b以下で§a二分法テレポートを使用(有効) §6または §cアンカー式テレポート(無効)", \
    option_uses_string_dimension: "文字列次元を認識するか", \
    option_uses_string_dimension_hoverevent: "§b以下で§a文字列で次元を保存 1.16+(有効) §6または §c整数で保存 1.16-(無効)", \
    option_version: "データパックバージョン", \
    option_warp: "公共テレポート地点", \
    option_warp_hoverevent: "§b以下のボタンで§a公共テレポート地点§6メニューを開く §b右の数字は設定済みの公共テレポート地点数", \
    option_warp_number_hoverevent_leftpart: "§bサーバーには現在 ", \
    option_warp_number_hoverevent_rightpart: "§b 個の公共テレポート地点があります", \
    option_uses_tick_scheduling: "/schedule コマンドで Tick 関数を呼び出すか", \
    output_default: "出力場所を§aチャットとアクションバー§rに切り替えました", \
    output_hide_actionbar: "出力場所を§aチャットのみ§rに切り替えました", \
    output_hide_chatbar: "出力場所を§aアクションバーのみ§rに切り替えました", \
    recver_accept_auto_hoverevent: "§bあなたにテレポートリクエストを送ったプレイヤー", \
    recver_accept_auto_left_part: "自動で受け入れた", \
    recver_accept_auto_right_part: "のテレポートリクエスト", \
    recver_accept_toggle_off: "§a自動受け入れ§rをオフにしました", \
    recver_accept_toggle_on: "§a自動受け入れ§rをオンにしました", \
    recver_accept_tpa_hoverevent: "§bあなたが受け入れたテレポートリクエストのプレイヤー", \
    recver_accept_tpa_left_part: "受け入れた", \
    recver_accept_tpa_right_part: "のテレポートリクエスト", \
    recver_accept_tpahere_hoverevent: "§bあなたが受け入れた§lここへテレポート§rリクエストのプレイヤー", \
    recver_accept_tpahere_left_part: "受け入れた", \
    recver_accept_tpahere_right_part: "の§lここへテレポート§rリクエスト", \
    recver_cancel_hoverevent: "§bキャンセルしたプレイヤー", \
    recver_cancel_left_part: "", \
    recver_cancel_right_part: "があなたへのリクエストをキャンセルしました", \
    recver_deny_tpa_hoverevent: "§bあなたのテレポートリクエストを拒否したプレイヤー", \
    recver_deny_tpa_left_part: "拒否した", \
    recver_deny_tpa_right_part: "のテレポートリクエスト", \
    recver_deny_tpahere_hoverevent: "§bあなたの§lここへテレポート§rリクエストを拒否したプレイヤー", \
    recver_deny_tpahere_left_part: "拒否した", \
    recver_deny_tpahere_right_part: "の§lここへテレポート§rリクエスト", \
    recver_recv_button_accept: "[§a受け入れる§r]", \
    recver_recv_button_accept_hoverevent: "§bクリックしてリクエストを受け入れる", \
    recver_recv_button_deny: "[§c拒否§r]", \
    recver_recv_button_deny_hoverevent: "§bクリックしてリクエストを拒否", \
    recver_recv_tpa_actionbar_left_part: "", \
    recver_recv_tpa_actionbar_right_part: "からテレポートリクエストが届きました。/trigger tpaccept で受け入れます", \
    recver_recv_tpa_chatbar_left_part: "", \
    recver_recv_tpa_chatbar_right_part: "からテレポートリクエストが届きました", \
    recver_recv_tpa_hoverevent: "§bあなたにテレポートリクエストを送ったプレイヤー", \
    recver_recv_tpahere_actionbar_left_part: "", \
    recver_recv_tpahere_actionbar_right_part: "から§lここへテレポート§rリクエストが届きました。/trigger tpaccept で受け入れます", \
    recver_recv_tpahere_chatbar_left_part: "", \
    recver_recv_tpahere_chatbar_right_part: "から§lここへテレポート§rリクエストが届きました", \
    recver_recv_tpahere_hoverevent: "§bあなたに§lここへテレポート§rリクエストを送ったプレイヤー", \
    recver_req_not_exist: "処理すべきリクエストはありません", \
    recver_timeout_hoverevent: "§bタイムアウトしたリクエストのプレイヤー", \
    recver_timeout_left_part: "", \
    recver_timeout_right_part: "のテレポートリクエストはタイムアウトしました", \
    reqer_accept_auto_hoverevent: "§bあなたのリクエストを自動で承諾したプレイヤー", \
    reqer_accept_auto_left_part: "相手が自動受け入れをオンにしており、あなたを", \
    reqer_accept_auto_right_part: "に転送中...", \
    reqer_accept_tpa_hoverevent: "§bあなたのテレポートリクエストを受け入れたプレイヤー", \
    reqer_accept_tpa_left_part: "あなたを", \
    reqer_accept_tpa_right_part: "に転送中...", \
    reqer_accept_tpahere_hoverevent: "§bあなたの§lここへテレポート§rリクエストを受け入れたプレイヤー", \
    reqer_accept_tpahere_left_part: "あなたを", \
    reqer_accept_tpahere_right_part: "のところへ転送中...", \
    reqer_button_tpa: "[§bテレポート§r]", \
    reqer_button_tpa_hoverevent: "§bクリックしてテレポートリクエストを送信", \
    reqer_button_tpahere: "[§bここへテレポート§r]", \
    reqer_button_tpahere_hoverevent: "§bクリックして相手をあなたの位置にテレポートさせるリクエストを送信", \
    reqer_cancel_hoverevent: "§bリクエストをキャンセルしたプレイヤー", \
    reqer_cancel_left_part: "", \
    reqer_cancel_right_part: "へのリクエストをキャンセルしました", \
    reqer_cancel_spec: "観戦者は§aリクエストをキャンセル§rできません", \
    reqer_change_actionbar_left_part: "以前、", \
    reqer_change_actionbar_middle_part: "へのリクエストを送信しました。前のリクエストをキャンセルしました。現在、", \
    reqer_change_actionbar_right_part: "にリクエストを送信中、承認待ちです。", \
    reqer_change_chatbar_left_part: "以前、", \
    reqer_change_chatbar_middle_part: "へのリクエストを送信しました。前のリクエストをキャンセルしました。現在、", \
    reqer_change_chatbar_right_part: "にリクエストを送信中、承認待ちです。", \
    reqer_change_hoverevent: "§b以前リクエストを送ったプレイヤー", \
    reqer_deny_tpa_hoverevent: "§bあなたのテレポートリクエストを拒否したプレイヤー", \
    reqer_deny_tpa_left_part: "", \
    reqer_deny_tpa_right_part: "あなたのテレポートリクエストを拒否しました", \
    reqer_deny_tpahere_hoverevent: "§bあなたの§lここへテレポート§rリクエストを拒否したプレイヤー", \
    reqer_deny_tpahere_left_part: "", \
    reqer_deny_tpahere_right_part: "あなたのリクエストを拒否しました", \
    reqer_disabled: "サーバーは§aテレポート§rを許可していません", \
    reqer_first_join: "[§6クリックしてTPAメニューを開く§r]", \
    reqer_no_req_found: "まだ誰にもリクエストを送信していません", \
    reqer_recver_invalid: "対象のプレイヤーはオフライン、またはテレポート不可です", \
    reqer_req_button_cancel: "[§4キャンセル§r]", \
    reqer_req_button_cancel_hoverevent: "§bクリックしてリクエストをキャンセル", \
    reqer_req_hoverevent: "§bあなたが送信したリクエストのプレイヤー", \
    reqer_req_not_exist: "リクエスト対象のプレイヤーは存在しないかオフラインです", \
    reqer_req_tpa_actionbar_left_part: "", \
    reqer_req_tpa_actionbar_right_part: "にテレポートリクエストを送信しました。承認待ちです", \
    reqer_req_tpa_chatbar_left_part: "", \
    reqer_req_tpa_chatbar_right_part: "にテレポートリクエストを送信しました。承認待ちです", \
    reqer_req_tpa_hoverevent: "§bあなたが送信したテレポートリクエストのプレイヤー", \
    reqer_req_tpahere_actionbar_left_part: "", \
    reqer_req_tpahere_actionbar_right_part: "にあなたの位置へテレポートさせるリクエストを送信しました。承認待ちです", \
    reqer_req_tpahere_chatbar_left_part: "", \
    reqer_req_tpahere_chatbar_right_part: "にあなたの位置へテレポートさせるリクエストを送信しました。承認待ちです", \
    reqer_req_tpahere_hoverevent: "§bあなたが送信した§lここへテレポート§rリクエストのプレイヤー", \
    reqer_self: "自分自身にはテレポートできません", \
    reqer_spam: "すでにリクエストを送信済みです", \
    reqer_spec: "観戦者は§aテレポート§rできません", \
    reqer_timeout_hoverevent: "§bあなたのリクエストを承認しなかったプレイヤー", \
    reqer_timeout_left_part: "", \
    reqer_timeout_right_part: "へのテレポートリクエストがタイムアウトしました", \
    search_id_abort: "§aプレイヤーID検索§r を停止しました", \
    search_id_dialog_done_tooltip: "§bクリックして名前を送信", \
    search_id_dialog_cancel: "キャンセル", \
    search_id_dialog_cancel_tooltip: "§bクリックして入力をキャンセル", \
    search_id_disabled: "§aプレイヤーID検索§r はサーバーで無効化されています", \
    search_id_incompatible: "§aプレイヤーID検索§r はこのゲームバージョンと互換性がありません", \
    search_id_keyboard_title: "下のキーボードをクリックして上部にプレイヤー名を入力してください: ", \
    search_id_name_input: "入力済み: ", \
    search_id_recall: "[§b再呼出§r]", \
    search_id_recall_hoverevent: "§bプレイヤーID検索キーボードを再呼出", \
    search_id_throw_on_invalid_char: "入力した名前に無効な文字が含まれています", \
    search_id_unavail_player: "相手がオフラインか、テレポートを許可していません", \
    simple_menu_button: "[§b詳細メニュー§r]", \
    simple_menu_button_hoverevent: "§bクリックして詳細メニューに切り替え", \
    simple_menu_disable: "TPAメニューを§a詳細メニュー§rに切り替えました", \
    simple_menu_incompatible: "§a簡略メニュー§r はこのゲームバージョンと互換性がありません", \
    simple_menu_enable: "TPAメニューを§a簡略メニュー§rに切り替えました §r今 /trigger tpa で簡略メニューを直接開けます", \
    simple_menu_title: "下のプレイヤー名をクリックしてテレポートリクエストを送信", \
    teleport_anchor_actionbar: "アンカーテレポート進行状況: ", \
    teleport_binary_actionbar: "二分法テレポート進行状況: ", \
    teleport_cal_sim_dist_actionbar: "シミュレーション距離", \
    teleport_cal_sim_dist_end_leftpart: "シミュレーション距離計算成功、現在サーバー設定のパケットシミュ距離: ", \
    teleport_cal_sim_dist_end_rightpart: "", \
    teleport_cal_sim_dist_start: "シミュレーション距離計算を開始しました", \
    teleport_incompatible: "§aアンカーテレポート§r はこのゲームバージョンと互換性がありません", \
    teleport_sim_dist_disabled: "サーバーはまだシミュレーション距離を設定していません", \
    teleport_sim_dist_warn: "サーバーがシミュレーション距離を設定していません。プレイヤー以外の対象にテレポートを試みています。失敗した場合は管理者に連絡し距離を再計算するか、手動で設定するか、二分法テレポートを使用してください", \
    teleport_sim_dist_warn_button_calc: "[§a計算§r]", \
    teleport_sim_dist_warn_button_calc_hoverevent: "§bクリックしてシミュレーション距離を自動計算開始  §c注意: 実行するとテレポート位置が変わる可能性があります   現在位置を安全に保つ場合のみクリックしてください", \
    teleport_sim_dist_warn_button_binary: "[§a二分法§r]", \
    teleport_sim_dist_warn_button_binary_hoverevent: "§bクリックしてテレポート方法を二分法に設定", \
    tick_not_working_button_set_schedule: "§b[設定]", \
    tick_not_working_button_set_schedule_hoverevent: "§bクリックして /schedule コマンドでTick関数を呼び出し", \
    tick_not_working_server_calling: "クライアントではなくコンソールから命令ブロックを使用してください！", \
    tick_not_working_server_calling_comment: "§l§n§c注釈: tick_not_working_server_calling はコンソールに表示する必要があります。漢字を直接書くと文字化けするため、ここではローマ字で表示しています", \
    tick_not_working_tips_line1: "現在 Tick不動関数を呼び出しています。そのため、Tick関数が動作しない状況に直面する可能性があります。次のどちらかの方法を実施してください:", \
    tick_not_working_tips_line2: "        1. /schedule コマンドで Tick関数を呼び出す", \
    tick_not_working_tips_line3: "   または 2. 命令ブロックを隠し場所に置いて、破壊防止", \
    tp_pos_abort: "座標入力を停止しました", \
    tp_pos_act_left_part: "座標にテレポートしました", \
    tp_pos_act_right_part: "", \
    tp_pos_button_abort: "[停止]", \
    tp_pos_button_teleport: "[テレポート]", \
    tp_pos_cooldown: "§a座標テレポート§r はクールダウン中です", \
    tp_pos_disabled: "サーバーで §a座標テレポート§r が有効化されていません", \
    tp_pos_dialog_cancel_tooltip: "§bクリックして入力をキャンセル", \
    tp_pos_dialog_done_tooltip: "§bクリックして入力した座標にテレポート", \
    tp_pos_dialog_set: "現在: ", \
    tp_pos_dialog_set_x: "X座標設定", \
    tp_pos_dialog_set_x_tooltip: "§bクリックして X座標を設定", \
    tp_pos_dialog_set_y: "Y座標設定", \
    tp_pos_dialog_set_y_tooltip: "§bクリックして Y座標を設定", \
    tp_pos_dialog_set_z: "Z座標設定", \
    tp_pos_dialog_set_z_tooltip: "§bクリックして Z座標を設定", \
    tp_pos_out_of_range: "テレポート距離がサーバー設定の半径を超えています", \
    tp_pos_recall: "[§b再呼出§r]", \
    tp_pos_recall_hoverevent: "§bクリックして座標メニューを再呼出", \
    tp_pos_spec: "観戦モードのプレイヤーは §a座標テレポート§r を使用できません", \
    tp_pos_throw_on_invalid_char: "入力した座標に無効な文字が含まれています", \
    tp_pos_title: "下で座標を調整: ", \
    tpa_menu_auto_accept: "自動承認: ", \
    tpa_menu_back_button: "[§b前の位置に戻る§r]", \
    tpa_menu_back_button_hoverevent: "§bテレポート前の位置に戻る", \
    tpa_menu_book_button: "[§bテレポートブック取得§r]", \
    tpa_menu_book_button_hoverevent: "§bクリックしてテレポートブックを取得", \
    tpa_menu_dialog: "[§bダイアログメニュー§r]", \
    tpa_menu_dialog_title: "§bTPAメニュー", \
    tpa_menu_dialog_hoverevent: "§bクリックしてダイアログメニューを開く", \
    tpa_menu_switch_hoverevent: "§bクリックして切り替え", \
    tpa_menu_disable: "§c無効化§r]", \
    tpa_menu_disabled: "§c無効", \
    tpa_menu_disabled_hoverevent: "§bクリックして§a有効化§r", \
    tpa_menu_enable: "[§a有効化§r", \
    tpa_menu_enabled: "§a有効", \
    tpa_menu_enabled_hoverevent: "§bクリックして§c無効化§r", \
    tpa_menu_extend: "§bもっと見る§r", \
    tpa_menu_extend_hoverevent: "§bクリックしてメニューを展開", \
    tpa_menu_has_id_of: "の§aデータパックID§r は", \
    tpa_menu_has_id_of_hoverevent: "§b各プレイヤーに割り当てられた内部ID、対応用", \
    tpa_menu_here_button: "[§b位置を通知§r]", \
    tpa_menu_here_button_hoverevent: "§bクリックして位置を通知", \
    tpa_menu_home_button: "[§bホームメニュー§r]", \
    tpa_menu_home_button_hoverevent: "§bクリックして個人テレポートポイント(ホーム)メニューを開く", \
    tpa_menu_warp_button: "[§bワープメニュー§r]", \
    tpa_menu_warp_button_hoverevent: "§bクリックして公共テレポートポイント(ワープ)メニューを開く", \
    tpa_menu_hoverevent_left_part: "§bクリックして", \
    tpa_menu_hoverevent_right_part: "§bテレポートリクエストを送信", \
    tpa_menu_idfix_button: "[§bID修復§r]", \
    tpa_menu_idfix_button_hoverevent: "§b同じIDを持つプレイヤーが2人いる場合に修復可能。すべてのプレイヤーIDをリセット", \
    tpa_menu_lang_button: "[§b言語切替§r]", \
    tpa_menu_lang_button_hoverevent: "§bクリックして言語を切替", \
    tpa_menu_mute: "データパックのミュート: ", \
    tpa_menu_output: "出力表示場所: ", \
    tpa_menu_output_actionbar: "§bチャット欄非表示§r", \
    tpa_menu_output_chatbar: "§bアクションバー非表示§r]", \
    tpa_menu_output_default: "[§bデフォルト§r", \
    tpa_menu_output_actionbar_hidden: "§bチャットのみ§r", \
    tpa_menu_output_chatbar_hidden: "§bアクションバーのみ§r", \
    tpa_menu_output_no_hidden: "§bアクションバーとチャット欄§r", \
    tpa_menu_pos_button: "[§b座標テレポート§r]", \
    tpa_menu_pos_button_hoverevent: "§bクリックして座標メニューを呼出", \
    tpa_menu_refresh: "[§6TPAメニュー更新§r]", \
    tpa_menu_refresh_hoverevent: "§bクリックしてTPAメニューを更新または再呼出", \
    tpa_menu_search_id_button: "[§bプレイヤー検索§r]", \
    tpa_menu_search_id_button_hoverevent: "§bクリックしてチャット欄キーボードを呼出しユーザー名検索", \
    tpa_menu_simplemenu_button: "[§b簡略メニュー§r]", \
    tpa_menu_simplemenu_button_hoverevent: "§b簡略メニューに切替", \
    tpa_menu_title: "下はプレイヤーデータパックIDとゲーム内ユーザー名、IDをクリックして他のプレイヤー§lにテレポートリクエスト§r: {", \
    tpa_menu_tpaheremenu_button: "[§bここにテレポートメニュー§r]", \
    tpa_menu_tpaheremenu_button_hoverevent: "§bクリックしてここにテレポートメニューを開く", \
    tpa_menu_tpamenu_button: "[§bテレポートメニュー§r]", \
    tpa_menu_tpamenu_button_hoverevent: "§bクリックしてテレポートメニューを開く", \
    tpa_menu_you: "あなた", \
    tpahere_menu_title: "下はプレイヤーデータパックIDとゲーム内ユーザー名、IDをクリックして他のプレイヤー§lにあなた§rをテレポートリクエスト: {", \
    uninstall_start: "アンインストール中... (0/2)", \
    uninstall_rmv_objs: "すべてのスコア項目を削除中... (0/2)", \
    uninstall_rmv_done_1: "削除成功. (1/2)", \
    uninstall_rmv_tags: "すべてのタグを削除中... (1/2)", \
    uninstall_rmv_done_2: "削除成功. (2/2)", \
    uninstall_done_leftpart: "§aアンインストール成功. 実行するには", \
    uninstall_done_hoverevent: "クリックしてコマンド実行", \
    uninstall_done_rightpart: "で再度有効化", \
    update_reload: "§b[リロード]", \
    update_reload_hoverevent: "クリックしてリロード", \
    update_step1_leftpart: "TPAデータパックのアップデートを実行中です。現在インストールされているデータパックのバージョンは ", \
    update_step1_rightpart: " です。ここで更新を開始することを確認してください", \
    update_step1_button: "§b§n§l[自分の操作を理解しています]", \
    update_step1_hoverevent: "慎重にクリックしてください", \
    update_step2: "最新バージョンのデータパックを GitHub、QQ グループ、または Modrinth からダウンロードしてください", \
    update_step3: "次のインストールのために右側のボタンをクリックしてデータパックを一時的に無効化してください", \
    update_step3_button: "§b[データパックを無効化]", \
    update_step3_hoverevent: "無効化できない場合は、データパックのファイル名が正しいか確認してください", \
    update_step4: "ほぼ完了です。データパックファイルを datapacks フォルダにドラッグして解凍し、古いデータパックを削除してください", \
    update_step5_leftright: "その後、TPAデータパックのインストールが完了します。データパックが正常に動作する場合は設定を調整してください。もし正しく読み込まれない場合は", \
    update_step5_button: "§b[ロード]", \
    update_step5_hoverevent: "クリックしてデータパックをロード", \
    update_step5_rightpart: " 不明なスコア項目が表示された場合はステップ3から確認してください。これはデータパックのインストールバージョンの不一致や不明な値が原因です。その他の問題は Xiao_tu233 に問い合わせてください", \
    update_nextstep: "§b[次へ]", \
    warp_button_add: "[§a新しいワープポイント§r]", \
    warp_button_add_hoverevent: "§bクリックして現在位置に新しい公共ワープポイントを作成", \
    warp_button_apply: "[§a適用§r]", \
    warp_button_apply_hoverevent: "§bクリックしてキャッシュされた変更を適用", \
    warp_button_cancel: "[§cキャンセル§r]", \
    warp_button_cancel_hoverevent: "§bクリックしてキャッシュされた変更を破棄", \
    warp_button_enable: "[§a有効化§r]", \
    warp_button_enable_hoverevent: "§bクリックしてこの公共ワープポイントを有効化", \
    warp_button_disable: "[§c無効化§r]", \
    warp_button_disable_hoverevent: "§bクリックしてこの公共ワープポイントを無効化（名前以外の情報は非表示、有効化で確認可能）", \
    warp_button_moveup: "[§d上に移動§r]", \
    warp_button_moveup_hoverevent: "§bクリックしてこのワープポイントを上のワープポイントと位置を入れ替え", \
    warp_button_moveup_notavail_hoverevent: "§c上に移動できません。このワープポイントはすでに最上部です", \
    warp_button_movedown: "[§d下に移動§r]", \
    warp_button_movedown_hoverevent: "§bクリックしてこのワープポイントを下のワープポイントと位置を入れ替え", \
    warp_button_tp: "[§bテレポート§r]", \
    warp_button_tp_hoverevent: "§bクリックしてこのワープポイントにテレポート", \
    warp_button_rm: "[§c削除§r]", \
    warp_button_rm_hoverevent: "§bクリックしてこのワープポイントを削除", \
    warp_button_select: "[§a選択§r]", \
    warp_button_select_hoverevent: "§bクリックしてこのワープポイントスロットを選択。変更適用時に使用されます", \
    warp_button_unselect: "[§c選択解除§r]", \
    warp_button_unselect_hoverevent: "§bクリックしてこのワープポイントスロットの選択を解除", \
    warp_button_setdesc: "[§a説明設定§r]", \
    warp_button_setdesc_hoverevent: "§bクリックしてこのワープポイントの説明を設定（クリック後、キーボード左矢印を押し、引用符内に入力して Enter）", \
    warp_button_setname: "[§a名前設定§r]", \
    warp_button_setname_hoverevent: "§bクリックしてこのワープポイントの名前を設定（クリック後、キーボード左矢印を押し、引用符内に入力して Enter）", \
    warp_button_setpos: "[§a位置設定§r]", \
    warp_button_setpos_hoverevent: "§bクリックしてこのワープポイントを現在位置に設定", \
    warp_desc_disabled: "§cこの公共ワープポイントは無効化されています", \
    warp_disabled: "§a公共ワープポイント§rはサーバーで無効化されています", \
    warp_menu_title: "サーバーに設定されている公共ワープポイント: ", \
    warp_menu_edit_tip: "現在編集モードです。下のインデックスから操作スロットを選択し、下のボタンでデータを変更、最後に適用をクリックして反映してください", \
    warp_number: "公共ワープポイント#", \
    warp_out_of_range: "この公共ワープポイントは未設定です", \
    warp_select_left_part: "", \
    warp_select_right_part: "を編集中のスロットとして選択しました", \
    warp_set_left_part: "", \
    warp_set_middle_part: "を", \
    warp_set_position: "座標", \
    warp_set_right_part: "", \
    warp_set_default_name: "名前未設定ワープポイント", \
    warp_slot_disabled_leftpart: "アクセスした公共ワープポイント", \
    warp_slot_disabled_rightpart: "は無効化されています", \
    warp_spec: "観戦モードのプレイヤーは§a公共ワープポイント§rにテレポートできません", \
    warp_teleport_left_part: "テレポートされました：", \
    warp_teleport_right_part: "" \
}, \
  {\
    lang: "zh_tw", \
    id: 3, \
    name: "zh_tw", \
    name_display: "正體中文（臺灣）", \
    header: "[§bTPA§r] ", \
    back_act: "已將你傳送至上一位置", \
    back_disabled: "伺服器不允許§a返回上一位置§r", \
    back_not_exist: "沒有找到上一位置", \
    back_spec: "旁觀者模式玩家不允許§a返回上一位置§r", \
    book_disabled: "§a傳送書§r不相容該遊戲版本", \
    book_lore: "§r§b右鍵開啟TPA選單. 丟出刷新. 切換至副手停止使用.", \
    book_title: "§r§b傳送選單書 §a[按Q刷新] ", \
    book_mainhand_busy: "請空手來獲得傳送書.", \
    book_spec: "旁觀者模式玩家不允許使用§a傳送書§r", \
    book_stop: "你已停止使用§a传送书§r, 可在TPA菜单里再次获取 ", \
    command_syntax_error: "指令格式錯誤", \
    extended_menu_title: "======================§bTPA§6 選單§r========================", \
    extended_menu_previous_page: "§b檢視上一頁", \
    extended_menu_next_page: "§b檢視下一頁", \
    here_button_tpa: "[§b請求傳送§r]", \
    here_button_tpa_hoverevent: "§b點擊快捷向他發送傳送請求", \
    here_voxel_hoverevent: "§b點擊新增VoxelMap路徑點", \
    here_xaero_hoverevent: "§6點擊新增Xaero's Minimap路徑點", \
    here_spec: "旁觀者模式玩家不允許使用§a廣播位置§r", \
    home_act_left_part: "已將你傳送至傳送點#", \
    home_act_right_part: "", \
    home_create: "你尚未建立傳送點", \
    home_create_button: "[§a新建§r]", \
    home_create_button_hoverevent: "§a點擊設定一個傳送點", \
    home_disabled: "伺服器未啟用§a傳送點§r", \
    home_display: "§b傳送點#", \
    home_display_tp_button: "[§b傳送§r]", \
    home_display_tp_button_hoverevent: "§b點擊傳送到這個傳送點", \
    home_display_rm_button: "[§c移除§r]", \
    home_display_rm_button_hoverevent: "§c點擊刪除這個傳送點", \
    home_display_set_button: "[§a設定§r]", \
    home_display_set_button_hoverevent: "§a點擊設定傳送點", \
    home_menu_title: "你現在擁有如下的傳送點欄位: ", \
    home_missing_hoverevent: "該傳送點尚未設定", \
    home_new: "§a新建: ", \
    home_number: "傳送點#", \
    home_not_found_left_part: "你存取的傳送點#", \
    home_not_found_hoverevent: "§b你存取的傳送點", \
    home_not_found_right_part: "不存在", \
    home_out_of_range_left_part: "你存取的傳送點#", \
    home_out_of_range_right_part: "超出了伺服器的限制", \
    home_remove_left_part: "你移除了傳送點#", \
    home_remove_hoverevent: "§b移除的傳送點", \
    home_remove_right_part: "", \
    home_set_left_part: "你把傳送點#", \
    home_set_middle_part: "設定為", \
    home_set_overworld: "§a主世界", \
    home_set_the_nether: "§c地獄", \
    home_set_the_end: "§e終界", \
    home_set_position: "座標", \
    home_set_right_part: "", \
    home_spec: "旁觀者模式玩家不允許操作§a傳送點§r", \
    idfix_act_left_part: "", \
    idfix_act_hoverevent: "§b這名玩家使用了ID修復", \
    idfix_act_right_part: "使用了§aID修復§r, 所有玩家的資料包ID與上一位置已被重設", \
    idfix_cooldown: "§aID修復§r還在冷卻中", \
    idfix_disabled: "伺服器不允許§aID修復§r", \
    lang_button: "[§6點擊這裡選擇語言§r]", \
    lang_button_server: "[§6點擊這裡選擇伺服器語言§r]", \
    lang_button_hoverevent: "§b點擊檢視語言選單", \
    lang_menu_title: "請在下方選擇語言:", \
    lang_menu_select_button: "[§a載入推薦指令§r]", \
    lang_menu_select_button_hoverevent: "§b點擊在聊天欄載入推薦指令: ", \
    lang_disabled: "伺服器禁止了玩家選擇語言", \
    lang_selected_left_part: "你已切換語言到", \
    lang_selected_right_part: "", \
    lang_server_follow_left_part: "由於資料包伺服器預設語言尚未設定, 現在它被設定為", \
    lang_server_follow_right_part: "", \
    load_title: "§e重新載入中...", \
    load_add_objectives: "正在新增42個計分項... (1/6)", \
    load_added_objectives: "已成功地新增計分項... (2/6)", \
    load_reset_scores: "正在重設線上玩家分數... (2/6)", \
    load_date_check_format: 123, \
    load_date_check_format_comment: "§r§l§n# 1 for year, 2 for month, 3 for day, '123' here means the format is Year-Month-Day", \
    load_date_check_year_prefix: "", \
    load_date_check_year_suffix: "年", \
    load_date_check_year_local_prefix: "(民國", \
    load_date_check_year_local_suffix: "年)", \
    load_date_check_month_prefix: "", \
    load_date_check_month_suffix: "月", \
    load_date_check_day_prefix: "", \
    load_date_check_day_suffix: "日", \
    load_did_reset_scores: "已成功重設線上玩家分數... (3/6)", \
    load_init_storage: "正在初始化相關指令儲存... (3/6)", \
    load_initted_storage: "已成功初始化相關指令儲存... (4/6)", \
    load_remove_tags: "正在移除標籤... (4/6)", \
    load_removed_tags: "已成功移除標籤... (5/6)", \
    load_init_vars: "正在初始化變數... (5/6)", \
    load_initted_vars: "已成功初始化變數... (6/6)", \
    load_done: "§a資料包重新載入完成: §r1.15 - 1.20.1 完整版 ", \
    load_version_hoverevent: "§b這是TPA資料包的版本, 而不是Minecraft版本.", \
    load_welcome: "歡迎使用TPA資料包! ", \
    load_copyright_claim: "版權所有 © 2024-2025 Xiao_tu233 保留所有權利. 不允許商業使用. 具體請點擊下方\"[協議]\"按鈕", \
    load_author: "此資料包由§6Xiao_tu233§r製作. ", \
    load_button_options: "[設定]", \
    load_button_options_hoverevent: "點擊變更資料包設定", \
    load_button_help: "[說明]", \
    load_button_help_hoverevent: "點擊檢視說明", \
    load_button_update: "[更新]", \
    load_button_update_hoverevent: "點擊開始更新資料包", \
    load_button_license: "[協議]", \
    load_button_license_hoverevent: "§b使用TPA資料包必須遵循我們在Github網站上的開源協議以及對§l§n商業§r§b使用的限制，否則將會存在§6§l侵權§r§b的風險，所以請您仔細認真閱讀全文", \
    mute_disable: "你開啟了§a資料包音效§r", \
    mute_enable: "你§a靜音§r了資料包", \
    option_carpet_disabled: "本功能需要Carpet模組作為依賴, 而伺服器尚未安裝Carpet模組. ", \
    option_title_line1: "======================§bTPA§6 設定選單§r=====================", \
    option_title_line2: "請在下方調整設定: (需重新呼出選單以檢視變更)", \
    option_button_enable: "§r[§a啟用§r", \
    option_button_disable: "§c停用§r]", \
    option_button_set: "§r[§a設定§r]", \
    option_debug_mode: "除錯模式", \
    option_tp_spec: "允許傳送旁觀者", \
    option_remove_offline: "是否在玩家離線後移除ID空位", \
    option_carpet_fake_player_fix: "Carpet模組假人修復", \
    option_back: "是否停用返回上一位置", \
    option_search_id: "是否停用搜尋ID", \
    option_book: "是否停用傳送書", \
    option_player_lang: "是否允許玩家語言選擇", \
    option_lang: "伺服器語言", \
    option_lang_hoverevent: "§b在下方進入語言選擇選單", \
    option_home: "擁有傳送點的個數", \
    option_home_hoverevent: "§b在下方變更§a擁有傳送點的個數 §r(§6單位: 個§r), §b填0來設定禁止傳送點 §b填-1來設定不限制傳送點的數量(不推薦)", \
    option_tp_pos: "傳送座標允許半徑", \
    option_tp_pos_hoverevent: "§b在下方變更§a傳送座標允許半徑 §r(§6單位: 公尺§r), §b填0來設定禁止傳送 §b填-1來設定不限制半徑(不推薦)", \
    option_tp_pos_cooldown: "傳送座標冷卻時間", \
    option_tp_pos_cooldown_hoverevent: "§b在下方變更§a冷卻時間 §r(§6單位: 1 遊戲刻 = 1/20 秒§r), §b填0來設定無冷卻 §b填-1來設定禁止傳送", \
    option_time_out: "傳送請求逾時時間", \
    option_time_out_hoverevent: "§b在下方變更§a傳送請求逾時時間 §r(§6單位: 1 遊戲刻 = 1/20 秒§r), §b填0來設定禁止傳送 §b填-1來設定永不逾時", \
    option_idfix_cooldown: "§bID修復冷卻時間", \
    option_idfix_cooldown_hoverevent: "§b在下方變更§aID修復冷卻時間 §r(§6單位: 1 遊戲刻 = 1/20 秒§r), §b填0來設定無冷卻 填-1來設定禁止ID修復", \
    option_frequency: "資料包執行頻率", \
    option_frequency_hoverevent: "§b在下方變更§a資料包執行頻率 §r(§6單位: 1 遊戲刻 = 1/20 秒§r), §b填0來禁止資料包執行", \
    option_sim_dist: "模擬距離", \
    option_sim_dist_hoverevent: "§b在下方變更§a模擬距離 §r(§6單位: 區塊§r) 請在點擊前保證主世界原模擬點距離內", \
    option_sim_dist_button_cal: "[§a計算§r]", \
    option_enabled: "§a啟用§r", \
    option_disabled: "§c停用§r", \
    option_button_uninstall: "[§4解除安裝§r]", \
    option_button_uninstall_hoverevent: "§4點擊此按鈕來§l§n解除安裝§r§4TPA資料包! 請考慮你是否真的需要!", \
    option_button_update: "[§4更新§r]", \
    option_button_update_hoverevent: "§b點擊開始更新資料包", \
    option_button_license: "[§4協議§r]", \
    option_button_license_hoverevent: "§b使用TPA資料包必須遵循我們在Github網站上的開源協議以及對§l§n商業§r§b使用的限制，否則將會存在§6§l侵權§r§b的風險，所以請您仔細認真閱讀全文", \
    option_button_help: "[§4說明§r]", \
    option_button_help_hoverevent: "§b點擊開啟說明選單", \
    output_default: "你將輸出位置切換為§a聊天欄和動作欄§r", \
    output_hide_actionbar: "你將輸出位置切換為§a僅聊天欄§r", \
    output_hide_chatbar: "你將輸出位置切換為§a僅動作欄§r", \
    recver_accept_tpa_left_part: "你接受了", \
    recver_accept_tpa_hoverevent: "§b你所接受傳送請求的玩家", \
    recver_accept_tpa_right_part: "的傳送請求", \
    recver_accept_tpahere_left_part: "你接受了", \
    recver_accept_tpahere_hoverevent: "§b你所接受§l傳送到此處§r請求的玩家", \
    recver_accept_tpahere_right_part: "的§l傳送到此處§r請求", \
    recver_accept_auto_left_part: "自動接受了", \
    recver_accept_auto_hoverevent: "§b向你發送傳送請求的玩家", \
    recver_accept_auto_right_part: "的傳送請求", \
    recver_accept_toggle_on: "你開啟了§a自動接受§r", \
    recver_accept_toggle_off: "你關閉了§a自動接受§r", \
    recver_cancel_left_part: "", \
    recver_cancel_hoverevent: "§b取消對你請求的玩家", \
    recver_cancel_right_part: "取消了对你的請求", \
    recver_deny_tpa_left_part: "你拒絕了", \
    recver_deny_tpa_hoverevent: "§b你所拒絕傳送請求的玩家", \
    recver_deny_tpa_right_part: "的傳送請求", \
    recver_deny_tpahere_left_part: "你拒絕了", \
    recver_deny_tpahere_hoverevent: "§b你所拒絕§l傳送到此處§r請求的玩家", \
    recver_deny_tpahere_right_part: "的§l傳送到此處§r請求", \
    recver_recv_button_accept: "[§a接受§r]", \
    recver_recv_button_accept_hoverevent: "§b點擊接受他的請求", \
    recver_recv_button_deny: "[§c拒絕§r]", \
    recver_recv_button_deny_hoverevent: "§b點擊拒絕他的請求", \
    recver_recv_tpa_chatbar_left_part: "", \
    recver_recv_tpa_hoverevent: "§b向你發送傳送請求的玩家", \
    recver_recv_tpa_chatbar_right_part: "向你發送了一個傳送請求", \
    recver_recv_tpa_actionbar_left_part: "", \
    recver_recv_tpa_actionbar_right_part: "向你發送了一個傳送請求, 點頭三次以接受請求, 搖頭三次以拒絕請求", \
    recver_recv_tpahere_chatbar_left_part: "", \
    recver_recv_tpahere_hoverevent: "§b向你發送§l傳送到此處§r請求的玩家", \
    recver_recv_tpahere_chatbar_right_part: "向你發送了一個§l傳送到此處§r請求", \
    recver_recv_tpahere_actionbar_left_part: "", \
    recver_recv_tpahere_actionbar_right_part: "向你發送了一個§l傳送到此處§r請求, 點頭三次以接受請求, 搖頭三次以拒絕請求", \
    recver_req_not_exist: "沒有需要處理的請求", \
    recver_timeout_left_part: "", \
    recver_timeout_hoverevent: "§b向你發送逾時請求的玩家", \
    recver_timeout_right_part: "的傳送請求已逾時", \
    reqer_accept_tpa_left_part: "正在傳送你至", \
    reqer_accept_tpa_hoverevent: "§b接受了你的傳送請求的玩家", \
    reqer_accept_tpa_right_part: "...", \
    reqer_accept_tpahere_left_part: "正在傳送", \
    reqer_accept_tpahere_hoverevent: "§b接受了你的§l傳送到此處§r請求的玩家", \
    reqer_accept_tpahere_right_part: "至你...", \
    reqer_accept_auto_left_part: "對方開啟了自動接受, 將你傳送至", \
    reqer_accept_auto_hoverevent: "§b自動同意了你的傳送請求的玩家", \
    reqer_accept_auto_right_part: "...", \
    reqer_button_tpa: "[§b傳送§r]", \
    reqer_button_tpa_hoverevent: "§b點擊傳送向他發送傳送請求", \
    reqer_button_tpahere: "[§b傳送至此處§r]", \
    reqer_button_tpahere_hoverevent: "§b點擊請求他傳送到你的目前位置", \
    reqer_cancel_left_part: "你取消了向", \
    reqer_cancel_hoverevent: "§b你取消了請求的玩家", \
    reqer_cancel_right_part: "的請求", \
    reqer_cancel_spec: "旁觀者模式玩家不允許§a取消請求§r", \
    reqer_change_chatbar_left_part: "你之前發送過了一個向", \
    reqer_change_hoverevent: "§b你之前發送請求的玩家", \
    reqer_change_chatbar_middle_part: "的請求, 已取消前一個請求. 現在向", \
    reqer_change_chatbar_right_part: "發送了請求, 等待他接受", \
    reqer_change_actionbar_left_part: "你之前發送過了一個向", \
    reqer_change_actionbar_middle_part: "的請求, 已取消前一個請求. 現在向", \
    reqer_change_actionbar_right_part: "發送了請求, 等待他接受, 搖頭三次以取消請求", \
    reqer_deny_tpa_left_part: "", \
    reqer_deny_tpa_hoverevent: "§b拒絕了你的傳送請求的玩家", \
    reqer_deny_tpa_right_part: "拒絕了你的傳送請求", \
    reqer_deny_tpahere_left_part: "", \
    reqer_deny_tpahere_hoverevent: "§b拒絕了你的§l傳送到此處§r請求的玩家", \
    reqer_deny_tpahere_right_part: "拒絕了你的傳送請求", \
    reqer_recver_invalid: "你請求的玩家已離線或不允許被傳送", \
    reqer_disabled: "伺服器不允許§a傳送§r", \
    reqer_first_join: "[§6點我開啟TPA選單§r]", \
    reqer_no_req_found: "你還未向玩家發送任何請求", \
    reqer_req_button_cancel: "[§4取消§r]", \
    reqer_req_button_cancel_hoverevent: "§b點擊取消請求", \
    reqer_req_hoverevent: "§b你所發送請求的玩家", \
    reqer_req_tpa_chatbar_left_part: "你向", \
    reqer_req_tpa_hoverevent: "§b你所發送傳送請求的玩家", \
    reqer_req_tpa_chatbar_right_part: "發送了一個傳送請求. 等待他接受", \
    reqer_req_tpa_actionbar_left_part: "你向", \
    reqer_req_tpa_actionbar_right_part: "發送了一個傳送請求. 等待他接受, 搖頭三次以取消請求", \
    reqer_req_tpahere_chatbar_left_part: "你向", \
    reqer_req_tpahere_hoverevent: "§b你所發送§l傳送到此處§r請求的玩家", \
    reqer_req_tpahere_chatbar_right_part: "發送了一個傳送他到你的所在位置請求. 等待他接受", \
    reqer_req_tpahere_actionbar_left_part: "你向", \
    reqer_req_tpahere_actionbar_right_part: "發送了一個傳送他到你的所在位置的請求. 等待他接受, 搖頭三次以取消請求", \
    reqer_req_not_exist: "請求的玩家不存在或不在線", \
    reqer_self: "你不能傳送你自己", \
    reqer_spam: "你已經向他發送過請求了", \
    reqer_spec: "旁觀者模式玩家不允許§a傳送§r", \
    reqer_timeout_left_part: "你向", \
    reqer_timeout_hoverevent: "§b未接受你的請求的玩家", \
    reqer_timeout_right_part: "的傳送請求已逾時", \
    search_id_disabled: "§a搜尋ID§r不相容該遊戲版本", \
    search_id_throw_on_invalid_char: "你輸入的名稱包含不合法的字元", \
    search_id_unavail_player: "對方離線或不允許被傳送", \
    simple_menu_disable: "你將TPA選單切換至§a詳細選單", \
    simple_menu_enable: "你將TPA選單切換至§a簡略選單 §r你現在可以直接使用/trigger tpa來開啟簡略選單", \
    simple_menu_title: "點擊下方玩家名稱發送傳送請求", \
    simple_menu_button: "[§b詳細選單§r]", \
    simple_menu_button_hoverevent: "§b點擊切換至詳細選單", \
    teleport_tryagain: "請重試", \
    tp_pos_act_left_part: "已將你傳送至座標", \
    tp_pos_act_right_part: "", \
    tp_pos_cooldown: "§a傳送座標§r還在冷卻中", \
    tp_pos_disabled: "伺服器不允許§a傳送座標§r", \
    tp_pos_out_of_range: "傳送距離超過了伺服器設定的半徑", \
    tp_pos_spec: "旁觀者模式玩家不允許§a傳送座標§r", \
    tp_pos_throw_on_invalid_char: "你輸入的座標包含不合法的字元", \
    tp_pos_title: "在下方調整坐標: ", \
    tp_pos_button_teleport: "[傳送]", \
    tp_pos_button_abort: "[停止]", \
    tp_pos_abort: "你已停止輸入傳送坐標", \
    tpa_menu_hoverevent_left_part: "§b點擊向", \
    tpa_menu_hoverevent_right_part: "§b發送傳送請求", \
    tpa_menu_title: "這是玩家遊戲使用者名稱和玩家資料包id, 點擊id發送傳送請求: ", \
    tpahere_menu_title: "這是玩家遊戲使用者名稱和玩家資料包id, 點擊id發送§l傳送到此處§r請求: ", \
    tpa_menu_extend_hoverevent: "§b點擊展開選單", \
    tpa_menu_extend: "§b展開§r", \
    tpa_menu_you: "你", \
    tpa_menu_has_id_of: "的§a資料包ID§r是", \
    tpa_menu_idfix_button: "[§bID修復§r]", \
    tpa_menu_idfix_button_hoverevent: "§b如果你遇到兩個相同玩家擁有同一id的問題, 你可以嘗試這個修復. 此修復會重設所有玩家的id.", \
    tpa_menu_search_id_button: "[§b搜尋ID§r]", \
    tpa_menu_search_id_button_hoverevent: "§b點擊呼出聊天欄鍵盤輸入tpa指令", \
    tpa_menu_tpamenu_button: "[§b傳送選單§r]", \
    tpa_menu_tpamenu_button_hoverevent: "§b點擊來跳轉到傳送選單", \
    tpa_menu_tpaheremenu_button: "[§b傳送至此處選單§r]", \
    tpa_menu_tpaheremenu_button_hoverevent: "§b點擊來跳轉到傳送至此處選單", \
    tpa_menu_back_button: "[§b返回上一位置§r]", \
    tpa_menu_back_button_hoverevent: "§b回到傳送前位置", \
    tpa_menu_lang_button: "[§b切換語言§r]", \
    tpa_menu_lang_button_hoverevent: "§b點擊切換語言", \
    tpa_menu_book_button: "[§b取得傳送書§r]", \
    tpa_menu_book_button_hoverevent: "§b點擊來取得傳送書", \
    tpa_menu_pos_button: "[§b傳送座標§r]", \
    tpa_menu_pos_button_hoverevent: "§b點擊呼出聊天欄鍵盤輸入tpa指令", \
    tpa_menu_here_button: "[§b廣播位置§r]", \
    tpa_menu_here_button_hoverevent: "§b點擊廣播你的位置", \
    tpa_menu_home_button: "[§b傳送點選單§r]", \
    tpa_menu_home_button_hoverevent: "§b點擊開啟傳送點(home)選單", \
    tpa_menu_auto_accept: "自動接受: ", \
    tpa_menu_mute: "靜音資料包: ", \
    tpa_menu_output: "輸出顯示位置: ", \
    tpa_menu_output_default: "[§b預設§r", \
    tpa_menu_output_actionbar: "§b隱藏聊天欄§r", \
    tpa_menu_output_chatbar: "§b隱藏動作欄§r]", \
    tpa_menu_enable: "[§a開啟§r", \
    tpa_menu_disable: "§c關閉§r]", \
    tpa_menu_refresh: "[§6刷新TPA選單§r]", \
    tpa_menu_refresh_hoverevent: "§b點擊此處刷新或重新呼出TPA選單", \
    tpa_menu_simplemenu_button: "[§b簡略選單§r]", \
    tpa_menu_simplemenu_button_hoverevent: "§b切換到簡略選單", \
    tick_not_working_cmdblk_name: "§r§b在合適的地方把它放下", \
    extended_menu_disabled: "§a展開選單§r不相容此遊戲版本", \
    simple_menu_disabled: "§a簡略選單§r不相容此遊戲版本", \
    book_check_missing: "檢測到傳送書遺失，已重新給予", \
    book_incompatible: "§a傳送書§r不相容此遊戲版本", \
    book_refresh: "你刷新了§a傳送選單書§r", \
    book_reget: "[§b重新取得§r]", \
    book_reget_hoverevent: "§b點擊重新取得傳送書", \
    book_stacking: "檢測到傳送書堆疊，已沒收多餘的書", \
    dimension_menu_button: "[§b維度設定選單§r]", \
    dimension_menu_button_hoverevent: "§b點擊設定維度", \
    dimension_overworld: "主世界", \
    dimension_the_nether: "下界", \
    dimension_the_end: "終界", \
    dimension_unknown: "未知維度", \
    dimension_unknown_detected_leftpart: "檢測到未知維度(", \
    dimension_unknown_detected_rightpart: ")，請在維度選單中設定：", \
    extended_menu_incompatible: "§a展開選單§r不相容此遊戲版本", \
    here_button_tpa_notavail_hoverevent: "§c玩家不允許被傳送", \
    hoverevent_suggest_tip: "§a你應將指令補全為：", \
    load_date_check_left_part: "目前版本發佈於", \
    load_date_check_right_part: "，請注意更新", \
    load_done_extra: " 完整版 ", \
    option_advenced_warn: "下方設定為進階設定，請勿隨意修改，除非你清楚自己在做什麼", \
    option_advenced_tip: "啟用除錯模式以調整更多設定（進階設定）", \
    option_anchor_search_retries: "尋找傳送錨點的重試次數", \
    option_anchor_search_retries_hoverevent: "§b在下方更改§a尋找傳送錨點的重試次數 §r(§6單位：次 §r或 §6遊戲刻／執行頻率§r)，§b調整過大會延長等待時間，過小可能導致錨點誤判或污染", \
    option_button_notworking: "[§4無法執行§r]", \
    option_button_notworking_hoverevent: "§b當遇到 Tick 函式無法執行（TPA 選單無法開啟）時請點擊", \
    option_carpet_fake_player_fix_incompatible: "Carpet 模組假人修復不相容此版本", \
    option_compact_ids: "是否在玩家離線後移除編號空位", \
    option_current_game_version: "目前偵測到的遊戲版本", \
    option_debug_mode_hoverevent: "§b點擊下方啟用以開啟除錯模式，這會在聊天欄提供排錯訊息，但同時也可能造成洗頻", \
    option_dimension: "已相容維度", \
    option_dimension_button_add: "[§a新增§r]", \
    option_dimension_button_add_hoverevent: "§b點擊新增維度", \
    option_dimension_button_edit_color: "[§a編輯顏色§r]", \
    option_dimension_button_edit_color_hoverevent: "§b點擊編輯該維度的主題顏色（原版 16 色英文或 #XXXXXX 十六進位）", \
    option_dimension_button_edit_id: "[§a編輯維度 ID§r]", \
    option_dimension_button_edit_namespaceid: "[§a編輯命名空間 ID§r]", \
    option_dimension_button_edit_name: "[§a編輯名稱§r]", \
    option_dimension_button_remove: "[§c移除§r]", \
    option_dimension_button_remove_notavail_hoverevent: "§c原版維度無法移除", \
    option_dimension_menu_title: "伺服器相容以下維度：", \
    option_dimension_number_hoverevent_leftpart: "§b伺服器目前相容了 ", \
    option_dimension_number_hoverevent_rightpart: " 個維度", \
    option_game_version: "資料包檔案相容的遊戲版本", \
    option_max_anchor_summons_attempts: "傳送錨點最大召喚嘗試次數", \
    option_max_anchor_summons_attempts_hoverevent: "§b在下方更改§a最大嘗試次數 §r(§6單位：次§r)，§b過大會增加卡頓，過小可能導致傳送失敗", \
    option_stricter_book_check: "更嚴格的傳送書檢查", \
    option_stricter_book_check_incompatible: "更嚴格的傳送書檢查不相容此版本", \
    option_stricter_book_check_disabled: "此功能需要 Bookshelf 資料包作為依賴，但伺服器尚未安裝", \
    option_server_calling: "Qing3 shi3yong4 Ke4hu4duan1, er2 bu2shi4 Kong4zhi4tai2 lai2 tiao2zheng3 she4zhi4!", \
    option_dimension_button_edit_id_hoverevent: "§b點擊編輯該維度的維度ID(點擊後請按下鍵盤上的左箭頭, 在冒號後填寫，輸入好後回車)", \
    option_dimension_button_edit_namespaceid_hoverevent: "§b點擊編輯該維度的命名空間ID(namespace:id, source location 形如minecraft:                       xxx)(點擊後請按兩次鍵盤上的左箭頭, 在引號中填寫, 輸入好後回車)", \
    option_dimension_button_edit_name_hoverevent: "§b點擊編輯該維度的顯示名稱(點擊後請按兩次鍵盤上的左箭頭, 在引號中填寫，輸入好後回車, 該項對於原版維度會跟隨語言設定而不是當前設定)", \
    option_dimension_button_remove_hoverevent: "§b點擊移除該維度", \
    option_dimension_hoverevent: "§b在下方設定按鈕開啟§a維度兼容§6菜單 §b同時右側的數字會是目前已兼容的維度數量", \
    option_server_calling_comment: "§l§n§4這裡是一個註解 因為上面的option_server_calling需要被控制台所顯示 如果直接寫漢字會被顯示為亂碼 這裡使用拼音來進行表示", \
    option_uses_binary_teleport: "是否使用二分法傳送", \
    option_uses_binary_teleport_hoverevent: "§b在下方選擇§a使用二分法傳送(啟用) §6抑或是 §c使用錨點傳送(禁用)", \
    option_uses_string_dimension: "是否識別字串維度", \
    option_uses_string_dimension_hoverevent: "§b在下方選擇§a用字串儲存維度1.16+(啟用) §6抑或是 §c用整型儲存維度1.16-(禁用)", \
    option_version: "資料包版本", \
    option_warp: "公共傳送點", \
    option_warp_hoverevent: "§b在下方設定按鈕開啟§a公共傳送點§6菜單 §b同時右側的數字會是目前已設定的公共傳送點數量", \
    option_warp_number_hoverevent_leftpart: "§b伺服器目前設定了 ", \
    option_warp_number_hoverevent_rightpart: "§b 個公共傳送點", \
    option_uses_tick_scheduling: "是否使用/schedule指令呼叫Tick函數", \
    search_id_abort: "你停止了§a搜尋玩家編號§r", \
    search_id_dialog_done_tooltip: "§b點擊提交名字", \
    search_id_dialog_cancel: "取消", \
    search_id_dialog_cancel_tooltip: "§b點擊取消輸入", \
    search_id_incompatible: "§a搜尋玩家編號§r不兼容該遊戲版本", \
    search_id_keyboard_title: "請點擊下方鍵盤按鍵來在上方輸入玩家名: ", \
    search_id_name_input: "已輸入: ", \
    search_id_recall: "[§b重新呼出§r]", \
    search_id_recall_hoverevent: "§b重新呼出搜尋玩家編號軟鍵盤", \
    simple_menu_incompatible: "§a簡略菜單§r不兼容此遊戲版本", \
    teleport_anchor_actionbar: "錨點傳送進度: ", \
    teleport_binary_actionbar: "二分法傳送進度: ", \
    teleport_cal_sim_dist_actionbar: "模擬距離", \
    teleport_cal_sim_dist_end_leftpart: "模擬距離計算成功, 目前伺服器所設定資料包模擬距離為: ", \
    teleport_cal_sim_dist_end_rightpart: "", \
    teleport_cal_sim_dist_start: "計算模擬距離已開始", \
    teleport_incompatible: "§a錨點傳送§r不兼容此遊戲版本", \
    teleport_sim_dist_disabled: "伺服器尚未設定模擬距離", \
    teleport_sim_dist_warn: "檢測到伺服器未設定模擬距離，當前嘗試對非玩家目標進行傳送。若出現失敗，請聯繫管理員重新計算距離，或手動設定參數，或使用二分法傳送", \
    teleport_sim_dist_warn_button_calc: "[§a計算§r]", \
    teleport_sim_dist_warn_button_calc_hoverevent: "§b點擊開始自動計算模擬距離   §c注意: 執行可能會導致執行者被傳送到其他位置   請確保你的位置不需要保持加載再點擊", \
    teleport_sim_dist_warn_button_binary: "[§a二分法§r]", \
    teleport_sim_dist_warn_button_binary_hoverevent: "§b點擊將傳送方式設定為二分法傳送", \
    tick_not_working_button_set_schedule: "§b[設定]", \
    tick_not_working_button_set_schedule_hoverevent: "§b點擊設定/schedule指令呼叫Tick函數", \
    tick_not_working_server_calling: "Qing3 shi3yong4 Ke4hu4duan1, er2 bu2shi4 Kong4zhi4tai2 lai2 huo4qu3 Ming4ling4fang1kuai4!", \
    tick_not_working_server_calling_comment: "§l§n§c這裡是一個註解 因為上面的tick_not_working_server_calling需要被控制台所顯示 如果直接寫漢字會被顯示為亂碼 這裡使用拼音來進行表示", \
    tick_not_working_tips_line1: "你現在正在呼叫Tick不工作函數 因此你應該遇到了Tick函數不工作的情況 你現在可以實現以下兩種方式的其中一種:", \
    tick_not_working_tips_line2: "        1. 設定使用/schedule指令呼叫Tick函數", \
    tick_not_working_tips_line3: "   或者 2. 把你手中的命令方塊放到隱蔽的位置 以避免被破基岩機破壞", \
    tp_pos_dialog_cancel_tooltip: "§b點擊取消輸入", \
    tp_pos_dialog_done_tooltip: "§b點擊傳送提交的座標", \
    tp_pos_dialog_set: "當前: ", \
    tp_pos_dialog_set_x: "設定X座標", \
    tp_pos_dialog_set_x_tooltip: "§b點擊設定X座標", \
    tp_pos_dialog_set_y: "設定Y座標", \
    tp_pos_dialog_set_y_tooltip: "§b點擊設定Y座標", \
    tp_pos_dialog_set_z: "設定Z座標", \
    tp_pos_dialog_set_z_tooltip: "§b點擊設定Z座標", \
    tp_pos_recall: "[§b重新呼出§r]", \
    tp_pos_recall_hoverevent: "§b點擊重新呼出傳送座標菜單", \
    tpa_menu_dialog: "[§b對話框菜單§r]", \
    tpa_menu_dialog_title: "§bTPA菜單", \
    tpa_menu_dialog_hoverevent: "§b點擊開啟對話框菜單", \
    tpa_menu_switch_hoverevent: "§b點擊切換", \
    tpa_menu_disabled: "§c禁用", \
    tpa_menu_disabled_hoverevent: "§b點擊切換到§a啟用", \
    tpa_menu_enabled: "§a啟用", \
    tpa_menu_enabled_hoverevent: "§b點擊切換到§c禁用", \
    tpa_menu_has_id_of_hoverevent: "§b資料包內部分配給每個玩家的編號 用於對應玩家", \
    tpa_menu_warp_button: "[§b地標菜單§r]", \
    tpa_menu_warp_button_hoverevent: "§b點擊開啟公共傳送點(地標)菜單", \
    tpa_menu_output_actionbar_hidden: "§b僅聊天欄§r", \
    tpa_menu_output_chatbar_hidden: "§b僅動作欄§r", \
    tpa_menu_output_no_hidden: "§b動作欄和聊天欄§r", \
    uninstall_start: "正在卸載... (0/2)", \
    uninstall_rmv_objs: "移除所有記分項... (0/2)", \
    uninstall_rmv_done_1: "成功移除. (1/2)", \
    uninstall_rmv_tags: "正在移除所有標籤... (1/2)", \
    uninstall_rmv_done_2: "成功移除. (2/2)", \
    uninstall_done_leftpart: "§a成功卸載。使用", \
    uninstall_done_hoverevent: "點擊執行命令", \
    uninstall_done_rightpart: "來再次啟用", \
    update_reload: "§b[重載]", \
    update_reload_hoverevent: "點擊重載", \
    update_step1_leftpart: "您正在進行TPA資料包的更新程序 目前已安裝的資料包版本是 ", \
    update_step1_rightpart: " 請在此確認開始更新", \
    update_step1_button: "§b§n§l[我知道我在做什麼]", \
    update_step1_hoverevent: "請謹慎點擊", \
    update_step2: "請從github、QQ群或Modrinth中下載最新版本的資料包備用", \
    update_step3: "請點擊右手邊的按鈕將資料包暫時禁用 以便下一步的安裝", \
    update_step3_button: "§b[禁用資料包]", \
    update_step3_hoverevent: "如果遇到無法禁用 請檢查資料包的檔案名稱是否正確", \
    update_step4: "我們即將完成，請將資料包檔案拖入datapacks資料夾並解壓 然後刪掉原來的資料包", \
    update_step5_leftright: "後，我們已經完成了TPA資料包的安裝 如果資料包使用沒有問題 請開始調整資料包設置 如果資料包沒有正確載入 請嘗試", \
    update_step5_button: "§b[載入]", \
    update_step5_hoverevent: "點擊載入資料包", \
    update_step5_rightpart: " 如果出現未知的計分項 請從第3步開始檢查 這可能是由資料包安裝版本不正確或未知不正確所導致的 其他問題請洽詢Xiao_tu233", \
    update_nextstep: "§b[下一步]", \
    warp_button_add: "[§a新增傳送點§r]", \
    warp_button_add_hoverevent: "§b點擊在當前位置新增一個公共傳送點", \
    warp_button_apply: "[§a應用§r]", \
    warp_button_apply_hoverevent: "§b點擊應用所儲存的更改", \
    warp_button_cancel: "[§c取消§r]", \
    warp_button_cancel_hoverevent: "§b點擊放棄所儲存的更改", \
    warp_button_enable: "[§a啟用§r]", \
    warp_button_enable_hoverevent: "§b點擊啟用該公共傳送點", \
    warp_button_disable: "[§c禁用§r]", \
    warp_button_disable_hoverevent: "§b點擊禁用該公共傳送點（除名字外的相關資訊將被隱藏，啟用以查看）", \
    warp_button_moveup: "[§d上移§r]", \
    warp_button_moveup_hoverevent: "§b點擊互換該公共傳送點與上方公共傳送點的位置", \
    warp_button_moveup_notavail_hoverevent: "§c無法上移，該傳送點已經位於最上方", \
    warp_button_movedown: "[§d下移§r]", \
    warp_button_movedown_hoverevent: "§b點擊互換該公共傳送點與下方公共傳送點的位置", \
    warp_button_tp: "[§b傳送§r]", \
    warp_button_tp_hoverevent: "§b點擊傳送到該公共傳送點", \
    warp_button_rm: "[§c移除§r]", \
    warp_button_rm_hoverevent: "§b點擊移除該公共傳送點", \
    warp_button_select: "[§a選擇§r]", \
    warp_button_select_hoverevent: "§b點擊選擇該公共傳送點槽位，作為應用時寫入更改的槽位", \
    warp_button_unselect: "[§c取消選擇§r]", \
    warp_button_unselect_hoverevent: "§b點擊取消選擇該公共傳送點槽位", \
    warp_button_setdesc: "[§a設描述§r]", \
    warp_button_setdesc_hoverevent: "§b點擊設置該公共傳送點的描述（點擊後請按下鍵盤上的左箭頭，在引號中填寫，輸入後回車）", \
    warp_button_setname: "[§a取名§r]", \
    warp_button_setname_hoverevent: "§b點擊設置該公共傳送點的名字（點擊後請按下鍵盤上的左箭頭，在引號中填寫，輸入後回車）", \
    warp_button_setpos: "[§a取址§r]", \
    warp_button_setpos_hoverevent: "§b點擊把該公共傳送點設置到當前位置", \
    warp_desc_disabled: "§c該公共傳送點已被禁用", \
    warp_disabled: "§a公共傳送點§r已被伺服器禁用", \
    warp_menu_title: "伺服器設定了以下的公共傳送點：", \
    warp_menu_edit_tip: "目前處於編輯模式，請在下方通過索引選擇操作槽位後，在下方按鈕更改具體資料，最後點擊應用來應用更改", \
    warp_number: "公共傳送點#", \
    warp_out_of_range: "該公共傳送點尚未設定", \
    warp_select_left_part: "你選中了", \
    warp_select_right_part: "作為正在編輯的槽位", \
    warp_set_left_part: "你把", \
    warp_set_middle_part: "設為", \
    warp_set_position: "座標", \
    warp_set_right_part: "", \
    warp_set_default_name: "未命名傳送點", \
    warp_slot_disabled_leftpart: "你所訪問的公共傳送點", \
    warp_slot_disabled_rightpart: "已被禁用", \
    warp_spec: "旁觀者模式玩家不允許傳送§a公共傳送點§r", \
    warp_teleport_left_part: "已將你傳送至", \
    warp_teleport_right_part: "" \
} \
]
data modify storage tpa:tpa lang append from storage tpa:tpa temp.lang[]
