execute as boidoxx if predicate yourpack:in_lava if entity @s[nbt={Health:0.0f}] run function yourpack:reward
