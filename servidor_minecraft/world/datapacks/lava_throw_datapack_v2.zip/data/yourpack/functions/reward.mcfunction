execute as @a[scores={lastHit=1}] run advancement grant @s only yourpack:lava_throw
tellraw @a [{"text":"🔥 "},{"selector":"@s"},{"text":" threw boidoxx into lava!"}]
scoreboard players set @a lastHit 0
