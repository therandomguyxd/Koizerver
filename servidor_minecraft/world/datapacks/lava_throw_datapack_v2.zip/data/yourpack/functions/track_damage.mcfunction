execute as boidoxx on attacker run scoreboard players set @s lastHit 1
